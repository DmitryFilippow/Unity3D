﻿using UnityEngine;
using System.Collections;

public class CubCamera : MonoBehaviour
{
    public PostEffectsBase Effect1;
    public PostEffectsBase Effect2;
    public BlurEffect Effect3;
    public static int plrcolor = 1;
    public static int encolor = 2;
    public static int scolor;

    public Material glmat;

    private void OnPostRenderOld()
    {
        if (GameCore.CurEvent != GameCore.PlayerWinLevelEvent || GameCore.CurEvent != GameCore.PlayerLoseEvent) 
        {

    GL.PushMatrix();
        glmat.SetPass(0);
        GL.LoadOrtho();

        GL.Begin(GL.LINES);              
            for (var i1 = 0; i1 < 10; i1++)//vert lines
            {
            GL.Vertex(new Vector3(0f, 0.001f +(i1/10f), 0));
           //GL.Color(new Color(0, 1f, 0, 0.5f));
            GL.Vertex(new Vector3(1f, (0.001f + (i1/10f)), 0));
            }
            for (var i2 = 0; i2 < 10; i2++)// hor lines
            {

                GL.Vertex(new Vector3( 0.001f + (i2 / 10f),0, 0));
                //GL.Color(new Color(0, 1f, 0, 0.5f));
                GL.Vertex(new Vector3((0.001f + (i2 / 10f)),1f, 0));

            }
            GL.End();            
            
            GL.PopMatrix();
        }
    }

// Use this for initialization
    private void Start()
    {


        Effect1 = (PostEffectsBase) this.GetComponent(typeof (EdgeDetectEffectNormals));
        Effect2 = (PostEffectsBase) this.GetComponent(typeof (EdgeDetectEffectNormals2));
        Effect3 = (BlurEffect) this.camera.GetComponent(typeof (BlurEffect));
    }

    // Update is called once per frame
    private void Update()
    {
        if (scolor == plrcolor)
        {
            SetColor(plrcolor);
            scolor = 0;
        }
        if (scolor == encolor)
        {
            SetColor(encolor);
            scolor = 0;
        }

    }

     void SetColor(int num)
    {
        if (num == plrcolor)
        {
            Effect1.enabled = false;
            Effect2.enabled = true;
            Effect3.enabled = false;
        }
        if (num == encolor)
        {
            Effect1.enabled = true;
            Effect2.enabled = false;
            Effect3.enabled = true;
        }
    }

}
