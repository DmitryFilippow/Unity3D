﻿using UnityEngine;
using System.Collections;

public class MenuButGUI : MonoBehaviour
{
    public Button mb;
    public Component MBTexture;
	// Use this for initialization
	void Start ()
	{
	   MBTexture = this.GetComponent(typeof (GUITexture));
	   ButAlpha(0.5f);
	}
	
    void ButAlpha(float a=0.0f)
    {
        MBTexture.guiTexture.color = new Color(MBTexture.guiTexture.color.r, MBTexture.guiTexture.color.g, MBTexture.guiTexture.color.b, a);
    }

	// Update is called once per frame
    private void Update()
    {
       //mb.GetState();
        //Debug.Log(k);
        if (this.guiTexture.HitTest(Input.mousePosition) == false)
        {
            ButAlpha(0.5f);
        }
        else
        {
            ButAlpha(1.0f);
        }

        if (this.guiTexture.HitTest(Input.mousePosition)==false && Input.GetMouseButton(0) && mb.GetState()==true)
        {

            mb.SendMessage("OnMouseUp");
           
        }

        if (this.guiTexture.HitTest(Input.mousePosition) == true && Input.GetMouseButtonUp(0) && mb.GetState()==false)
        {
            mb.SendMessage("OnMouseDown");

        }


        if (this.guiTexture.HitTest(Input.mousePosition))
        {
            if (Input.GetMouseButtonDown(0))
            {
                mb.SendMessage("OnMouseDown");
                
                GameCore.ButEvent = mb.ButEvent;
                mb.SendMessage("OnMouseUp");
            }
            if (Input.GetMouseButtonUp(0))
            {
                mb.SendMessage("OnMouseUp");
            }
        }
        
        }
    
}
