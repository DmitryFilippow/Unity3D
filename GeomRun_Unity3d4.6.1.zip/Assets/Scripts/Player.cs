﻿using System.Collections.Generic;
using System.Threading;
using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour
{
    
    public Camera FollowCamera;
    public GameObject Plat1Prot; // ver ||
    public GameObject Plat2Prot; // hor =
    public GameObject Plat3Prot; // |``
    public GameObject Plat4Prot; // ``|
    public GameObject PlatFProt; // Finish

    public TextMesh Kostinum;
    public GameObject IllumPlane;
    public Light PPLight;

    public GameObject CubKosti;

    public static int rstep;

    private float dt = 0.0175f;
    private float tmr = 1.0f;
    public float ct = 0;

    public float PlrSpeed = 0.1f;
    public float ppltmr = 0.5f;

    public static int PState;
    public static int PStateWait = 0;
    public static int PStateGo = 1;

    // public static int sn;
    public int EndTmrS = 0;
    public int g1 = 0;

    public Transform ttrans;

    public Transform[] lvlsp,lvlse;

    public Enemy EnemyProt;

    public GameCore GC;

    // Use this for initialization
    public void GoToStartLevelPos0()
    {
        Debug.Log(2222222);
        SetDefVars();
        this.transform.localPosition = lvlsp[GameCore.StartLevel].transform.localPosition;
        this.transform.localRotation = lvlsp[GameCore.StartLevel].transform.localRotation;
    }

void SetDefVars()
    {
        rstep = 0;
        tmr = rstep;
        PState = PStateWait;
        UpdateKostinum(rstep);
        PlrSpeed = 0.1f;
        ct = 0;
        StopCoroutine("PTimer1");
    }
    private void Start()
    {
        SetDefVars();
        
    }
    private IEnumerator StartTimerP()
    {
        IllumPlane.SetActive(true);
        StartCoroutine("PTimer1");
        yield return new WaitForSeconds(tmr);
    }

    private IEnumerator PTimer1()
    {
        while (true)
        {
            if (GameCore.CurEvent != GameCore.PlayerLoseEvent)
            {
                this.transform.Translate(-PlrSpeed, 0, 0);
                ct = ct + dt;
                CubCamera.scolor = CubCamera.plrcolor;
                GameCore.MSGN = GameCore.MSGWait;
            }
            if (ct >= tmr)
            {
                ct = 0;
                IllumPlane.SetActive(false);
                //StopCoroutine("PTimer1");
                StopAllCoroutines();
                rstep = 0;
                UpdateKostinum(rstep);
                Enemy.EState = Enemy.EStateGo;
                PState = PStateWait;
                EndTmrS = 1;
            }
            yield return null;
        }
    }

    // Update is called once per frame
    private void Update()
    {
        if (GameCore.CurEvent == GameCore.NewGameEvent)
        {
            Debug.Log(11111111111111);
            SetDefVars();
            this.transform.localPosition = lvlsp[GameCore.StartLevel].transform.localPosition;
            this.transform.localRotation = lvlsp[GameCore.StartLevel].transform.localRotation;
            GameCore.CurEvent = GameCore.BackToGameEvent;
        }

        if (GameCore.CurEvent == GameCore.NextLevelEvent)
        {

            Debug.Log(14141);
            SetDefVars();
        }

        FollowCamera.transform.position = new Vector3(this.transform.position.x + 6.5f,
                                                      FollowCamera.transform.position.y,
                                                      this.transform.position.z - 18);

        if (GameCore.CurEvent == GameCore.BackToGameEvent)
        {

            switch (Application.platform)
            {
                case RuntimePlatform.WindowsPlayer:
                    CheckKeys();
                    break;

                case RuntimePlatform.WindowsEditor:
                    CheckKeys();
                    break;

                case RuntimePlatform.WindowsWebPlayer:
                    CheckKeys();
                    break;

                case RuntimePlatform.Android:
                    CheckAndroidKeys();
                    break;
            }

            // kosti num + Plane + pointlight timer
            if (GameCore.CurEvent != GameCore.PlayerLoseEvent)
            {
            Kostinum.transform.position = new Vector3(this.transform.position.x - 2, Kostinum.transform.position.y,
                                                      this.transform.position.z - 0.1f);
            IllumPlane.transform.position = new Vector3(this.transform.position.x, Kostinum.transform.position.y - 4.9f,
                                                        this.transform.position.z);
            
                if (Time.time > ppltmr)
                {
                    ppltmr = ppltmr + 0.1f;
                    PPLight.transform.position = new Vector3(PPLight.transform.position.x, Random.Range(0.2f, 1.0f),
                                                             PPLight.transform.position.z);
                }
            }// kosti num + Plane + pointlight timer

        }

    }

    private void UpdateKostinum(int i)
    {
        Kostinum.text = "Kosti = " + i;
    }

    private void CheckAndroidKeys()
    {



        //curevent sost = ni vigral ne proigral
        if (GameCore.CurEvent != GameCore.PlayerLoseEvent)
        {
            // hod igroka i najat space
            if (GameCore.CurTurn == GameCore.PlayerTurn && Enemy.erstep == 0 &&
                rstep == 0 && CubePol.SAct == 1 && CubePol.g2 != 1 && Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began)
            {
                CubePol.CubStop = false;
                CubePol.SAct = 0;
                g1 = 1;
            }
            //hod igroka i cubik ostanovilsya!
            if (GameCore.CurTurn == GameCore.PlayerTurn && CubePol.CubStop == true && CubePol.ct == 0 && g1 == 1 && Cub.State == 1)
            {
                g1 = 0;
                EndTmrS = 0;
                rstep = CubePol.Kosti;
                tmr = rstep;
                UpdateKostinum(rstep);
                StartCoroutine(StartTimerP());
                PState = PStateWait;
            }
        }

    }

    private void CheckKeys()
    {
        //curevent sost = ni vigral ne proigral
        if (GameCore.CurEvent != GameCore.PlayerLoseEvent) 
        {
            // hod igroka i najat space
            if (GameCore.CurTurn == GameCore.PlayerTurn && GameCore.KeySpaceIsPressed && Enemy.erstep == 0 &&
                rstep == 0 && CubePol.SAct == 1 && CubePol.g2 != 1)
            {
                CubePol.CubStop = false;
                CubePol.SAct = 0;
                g1 = 1;
            }
            //hod igroka i cubik ostanovilsya!
            if (GameCore.CurTurn == GameCore.PlayerTurn && CubePol.CubStop == true && CubePol.ct == 0 && g1 == 1 && Cub.State == 1)
            {
                g1 = 0;
                EndTmrS = 0;
                rstep = CubePol.Kosti;
                tmr = rstep;
                UpdateKostinum(rstep);
                StartCoroutine(StartTimerP());
                PState = PStateWait;
            }
        }
    }

    
    void GoToNextLevel()
    {
        
        if (GameCore.CurLevel != GameCore.FinishLevel)
        {
            
            GameCore.CurLevel = GameCore.CurLevel + 1;

            GC.ResetObjects();

            Debug.Log(GameCore.CurLevel);
            if (GameCore.CurLevel > GameCore.FinishLevel)
            {
                GameCore.CurLevel = 0;
                GameCore.ButEvent = "Menu Event";
                GameCore.CurEvent = GameCore.PauseGameEvent;
            }
            if (lvlsp[GameCore.CurLevel] && lvlse[GameCore.CurLevel])
            {
                this.transform.localPosition = lvlsp[GameCore.CurLevel].transform.localPosition;
                this.transform.localRotation = lvlsp[GameCore.CurLevel].transform.localRotation;
                EnemyProt.transform.localPosition = lvlse[GameCore.CurLevel].transform.localPosition;
                EnemyProt.transform.localRotation = lvlse[GameCore.CurLevel].transform.localRotation;
            }
        }
    }

    void OnTriggerStay(Collider ColObj)
    {
        // igrok stoit na finishe
        if (GameCore.CurEvent != GameCore.PlayerLoseEvent)
        {
            
            if (ColObj.name == PlatFProt.name)
            {
                
                
                SetDefVars();
                StopAllCoroutines();
                GameCore.MSGN = GameCore.MSGPlayerWin;
            }
        }
    }

    void OnTriggerEnter(Collider ColObj)
    {
        // igrok voshol v finish
        if (GameCore.CurEvent != GameCore.PlayerLoseEvent)
        {
            if (ColObj.name == PlatFProt.name)
            {
                GoToNextLevel();
                SetDefVars();
                StopAllCoroutines();
                GameCore.MSGN = GameCore.MSGPlayerWin;

            }

            //igrok voshol v platforme = plat1prot tipa
            if (ColObj.name == Plat1Prot.name)
            {
                PlrSpeed = 0.1f*1.3f;
            }
            //igrok voshol v platforme = plat2prot tipa
            if (ColObj.name == Plat2Prot.name)
            {
                PlrSpeed = 0.1f*1.3f;
            }
            //igrok voshol v platforme = plat3prot tipa
            if (ColObj.name == Plat3Prot.name) // |``
            {
                PlrSpeed = 0.1f*1.3f;
                this.transform.Rotate(0, -90, 0);
            }
            //igrok voshol v platforme = plat4prot tipa
            if (ColObj.name == Plat4Prot.name) // ``|
            {
                PlrSpeed = 0.1f*1.3f;
                this.transform.Rotate(0, 90, 0);
            }
        }
    }
    /*
        IEnumerator Example()
    {
        print(Time.time);
        yield return new WaitForSeconds(5);
        print(Time.time);
    }
     */
}