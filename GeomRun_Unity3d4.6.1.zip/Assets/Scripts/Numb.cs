﻿using UnityEngine;
using System.Collections;

public class Numb : MonoBehaviour
{
    public string NumbText;
    public TextMesh TextComp;
	// Use this for initialization
	void Start ()
	{
	    this.tag = "GOTag";
	    TextComp = (TextMesh) this.GetComponent(typeof (TextMesh));
	    //TextComp.text = NumbText;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
