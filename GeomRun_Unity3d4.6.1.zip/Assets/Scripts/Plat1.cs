﻿using UnityEngine;
using System.Collections;

public class Plat1 : MonoBehaviour
{
    public GameObject NPrefab;
    public TextMesh NTextComp;
    public Color TColor;
    public string NText;

    // Use this for initialization
    private void Start()
    {

        GameObject n = (GameObject) Instantiate(NPrefab, this.transform.position, NPrefab.transform.rotation);
        n.transform.parent = this.gameObject.transform;
        NTextComp = (TextMesh) n.GetComponent(typeof (TextMesh));
        NTextComp.text = NText;
        n.name = NPrefab.name + NText;
        NTextComp.color = TColor;

    }

    // Update is called once per frame
    private void Update()
    {
    }
}