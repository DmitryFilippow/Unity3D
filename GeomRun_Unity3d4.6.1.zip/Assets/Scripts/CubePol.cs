﻿using UnityEngine;
using System.Collections;

public class CubePol : MonoBehaviour
{

    public GameObject s1;
    public GameObject s2;
    public GameObject s3;
    public GameObject s4;
    public GameObject s5;
    public GameObject s6;

    public GameObject CubKosti;

    public static  float ct = 0;
    private float dt = 0.0175f;
    public static float btmr =4.7f;// 4.7 - pk //

    public static bool CubStop = false;
    public static int Kosti,KostiT;

    public static int SAct=1;
    public static int g2 = 0;
    // Use this for initialization
    private void Start()
    {
        CubKosti.rigidbody.Sleep();
    }

    // Update is called once per frame
    private void Update()
    {
        CheckBrosok();
    }

    void CheckBrosok()
    {

        if (SAct == 0)
        {
 
            Debug.Log("Brosok");
            CubKosti.rigidbody.AddForce(Random.Range(-1000, 1000), 1500, Random.Range(-1000, 1000));
            CubKosti.rigidbody.AddTorque(Random.Range(-1640f, 1640f), Random.Range(-2640f, 2640f), Random.Range(-3640f, 3640f));
            g2 = 1;
            SAct = 1;
            StartCoroutine(StartBrosokTimer());
            
        }
    }

    IEnumerator StartBrosokTimer()
    {
        
        StartCoroutine("BrosokTimer");
        yield return new WaitForSeconds(btmr);
    }

    IEnumerator BrosokTimer()
    {
        while (true)
        {
    
            ct = ct + dt;
            if (ct >= btmr)
            {
                Kosti = KostiT;
                ct = 0;
                g2 = 0;
                StopCoroutine("BrosokTimer");
                Debug.Log("Konec broska");
                CubStop = true;
                SAct = 1;
            }
            yield return null;
        }
    }

    private void OnTriggerExit(Collider ColObj)
    {
    }

    private void OnTriggerEnter(Collider ColObj)
    {
       // Cub.kostb = true;
        if (ColObj.name == s1.name)
        {

            KostiT = 1;
        }
        if (ColObj.name == s2.name)
        {

            KostiT = 2;
        }
        if (ColObj.name == s3.name)
        {

            KostiT = 3;
        }
        if (ColObj.name == s4.name)
        {

            KostiT = 4;
        }
        if (ColObj.name == s5.name)
        {

            KostiT = 5;
        }
        if (ColObj.name == s6.name)
        {

            KostiT = 6;
        }
    }
}
