﻿using UnityEngine;
using System.Collections;
//using UnityEditor;

//[ExecuteInEditMode]

public class Button : MonoBehaviour
{

    public Color BColor1;
    public Color BColor2;
    public Color BColor3;
    public GameObject ButCorp;
    public GameObject But;
    public TextMesh ButText;
    public string BCaption;
    public string BEventText;
    public string ButEvent;
    private bool MBSTATE;

    public bool RenderEnable;
    
	// Use this for initialization
	void Start ()
	{
	    RenderEnable = true;
	    ButText.color = BColor1;
	    ButText.text = BCaption;
	    ButEvent = BEventText;
	}
	
	// Update is called once per frame
    private void Update()
    {
	}

    void OnMouseEnter()
    {
        ButText.color = BColor2;
    }
    void OnMouseExit()
    {
        ButText.color = BColor1;
    }
    void OnMouseDown()
    {
        MBSTATE = true;
       
        ButText.color = BColor3;
        But.transform.localScale = new Vector3(But.transform.localScale.x, But.transform.localScale.y, But.transform.localScale.z/2);
        
    }

    void OnMouseUp()
    {
        Debug.Log("OMUP");
            GameCore.ButEvent = ButEvent;
            MBSTATE = false;
            ButText.color = BColor1;
            But.transform.localScale = new Vector3(But.transform.localScale.x, But.transform.localScale.y,
                                                   But.transform.localScale.z*2);
    }

    public bool GetState()
    {
        return MBSTATE;
    }
}
