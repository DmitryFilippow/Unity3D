﻿using UnityEngine;
using System.Collections;

public class GameCore : MonoBehaviour
{

    public GameObject CubCam;

    public GameObject PlayerProt;
    public GameObject EnemyProt;

    public Transform PlayerPos, EnemyPos;
    public GUIText TText;
    public GUIText MText;

    public static int CurTurn; //0 - player 1 - enemy

    public static int CurLevel = 0; // 0 -default
    public static int StartLevel = 0;
    public static int FinishLevel=10;
    public static int CurEvent;


    public static int PlayerTurnEvent = 100;
    public static int EnemyTurnEvent = 101;

    public static int PlayerWinLevelEvent = 102;
    public static int PlayerLoseEvent = 103;

    public static int PlayerStayEvent = 105;
    public static int EnemyStayEvent = 106;

    public static int PlayerTurn = 0;
    public static int EnemyTurn = 1;

    public static int NullEvent = 0;
    public static int MainMenuEvent = 1;
    public static int OptionsEvent = 2;
    public static int SaveGameEvent = 3;
    public static int LoadGameEvent = 4;
    public static int NewGameEvent = 5;
    public static int ExitGameEvent = 6;
    public static int BackToGameEvent = 7;
    public static int PauseGameEvent = 8;

    public static int NextLevelEvent = 9;

    public static int GameMode;
    public static int GameModeRunEvent = 0;
    public static int GameModeRaceEvent = 1;
    public static int GameModeRunPvPEvent = 2;
    public static int GameModeRacePvPEvent = 3;

    private string PTurnT = "Current turn = Player";
    private string ETurnT = "Current turn = Enemy";
    private string Message1 = "Wait";
    private string Message2 = "Press [Space] for your turn";
    private string Message3 = "You win";
    private string Message4 = "You Lose";

    public string NullEventS = "NullEvent";
    public static string ButEvent;
    public Button BGButton;
    public Button NGButton;
    public Button LGButton;
    public Button EButton;
    public GameObject GameTitle;

    public GameObject MenuG;
    public GameObject MenuB;
    public GameObject A1;
    public GameObject[] FindObjs,FindObjsN;
    public static int BPress = 0;
    public Vector3 p1;
    public Vector3 e1;
    public Quaternion p1r, e1r;
    [SerializeField]
    public static string CurEventDebugString;
    public string CurEventDebugStringp;

    public static int MSGN;
    public static int MSGPlayerLose = 1;
    public static int MSGPlayerWin = 0;
    public static int MSGWait = 2;
    public static int MSGGo = 3;

    public static bool KeySpaceIsPressed = false;

    public static bool FirstRun = true; // back to game -/ true = hide  /false = non hide
    // Use this for initialization

    public GameObject[] LvlSGraphics;
    public GameObject[] LvlSPL;

    public void SetDefVars()
    {
    
        FirstRun = true;

        CurEvent = NewGameEvent;
        ButEvent = NGButton.ButEvent;

        PlayerPos = PlayerProt.gameObject.transform;
        p1 = PlayerPos.transform.localPosition;
        p1r = PlayerProt.transform.localRotation;
        EnemyPos = EnemyProt.gameObject.transform;
        e1 = EnemyPos.transform.localPosition;
        e1r = EnemyProt.gameObject.transform.localRotation;

        GameMode = GameModeRunEvent;
        CurTurn = PlayerTurn;

        for (int i = 0; i < 9; i++)
        {
            Debug.Log(i);
            if (LvlSGraphics[i] && LvlSPL[i])
            {
                LvlSGraphics[i].gameObject.SetActive(false);
                LvlSPL[i].gameObject.SetActive(false);
            }
        }
        LvlSGraphics[CurLevel].gameObject.SetActive(true);
        LvlSPL[CurLevel].gameObject.SetActive(true);

    }

    private void Start()
    {
        switch (Application.platform)
        {
            case RuntimePlatform.WindowsPlayer:
                CubePol.btmr = 4.7f;
                break;

            case RuntimePlatform.WindowsEditor:
                CubePol.btmr = 4.7f;
                break;

            case RuntimePlatform.WindowsWebPlayer:
                CubePol.btmr = 4.7f;
                break;

            case RuntimePlatform.Android:
                CubePol.btmr = 3.0f;
                break;
        }

            SetDefVars();
            CurEvent = PauseGameEvent;
            ButEvent = "MenuEvent";
    }

    private void GetObjs()
    {
        FindObjsN = GameObject.FindGameObjectsWithTag("NTag");
        FindObjs = GameObject.FindGameObjectsWithTag("GOTag");
    }

    // Update is called once per frame
    private void Update()
    {

        if (CurEvent != PlayerWinLevelEvent || CurEvent != PlayerLoseEvent)
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {
                KeySpaceIsPressed = true;
            }
            else
            {
                KeySpaceIsPressed = false;
            }
        }
        CurEventDebugStringp = CurEventDebugString;
        UpdateMenuEvents();
        CheckTurn();
        CheckEvents();
        UpdateMessages(MSGN);
    }

    void UpdateMessages(int msgN)
    {
        switch (msgN)
        {
            case 0:
                MText.text = Message3;
            break;
            case 1:
                MText.text = Message4;
            break;
            case 2:
                MText.text = Message1;
            break;
            case 3:
                MText.text = Message2;
            break;
        }
    }


    private void UpdateMenuEvents()
    {
        GetObjs();
        if (ButEvent == "MenuEvent")
        {
                switch (FirstRun)
                {
                    case true:
                        BGButton.RenderEnable = false;
                        GameTitle.SetActive(true);

                        break;

                    case false:
                        BGButton.RenderEnable = true;
                        GameTitle.SetActive(false);

                        break;
                }
                BGButton.gameObject.SetActive(BGButton.RenderEnable);
                BGButton.ButText.gameObject.SetActive(BGButton.RenderEnable);
                BGButton.ButCorp.gameObject.SetActive(BGButton.RenderEnable);
            
            

            MenuB.SetActive(false);
            MenuG.SetActive(true);
            

            Debug.Log("Menu");
            CurEvent = PauseGameEvent;

        }

        if (ButEvent == BGButton.BEventText)
        {

            MenuB.SetActive(true);
            MenuG.SetActive(false);
            GameTitle.SetActive(false);

            CurEvent = BackToGameEvent;

            
        }
        if (ButEvent == EButton.BEventText)
        {
            FindObjs = null;
            CurEvent = ExitGameEvent;
            Application.Quit();
            Debug.Log(ButEvent);

        }
        if (ButEvent == NGButton.BEventText)
        {
            MenuB.SetActive(true);
            MenuG.SetActive(false);
            GameTitle.SetActive(false);

            CurEvent = NewGameEvent;
            ButEvent = "BGEvent";
            
            PlayerProt.SendMessage("GoToStartLevelPos0");
            EnemyProt.SendMessage("GoToStartLevelPos0");
            CurLevel = StartLevel;

            ResetObjects();
        }
        if (ButEvent == LGButton.BEventText)
        {
            CurEvent = LoadGameEvent;
            Debug.Log(ButEvent);

        }

       // ButEvent = NullEventS;

    }

    public void ResetObjects()
    {
        for (int i = 0; i < 9; i++)
        {
            Debug.Log(i);
            if (LvlSGraphics[i] && LvlSPL[i])
            {
                LvlSGraphics[i].gameObject.SetActive(false);
                LvlSPL[i].gameObject.SetActive(false);
            }
        }
        if (CurLevel <= FinishLevel && LvlSGraphics[CurLevel] && LvlSPL[CurLevel])
        {
            LvlSGraphics[CurLevel].gameObject.SetActive(true);
            LvlSPL[CurLevel].gameObject.SetActive(true);
        }
    }

    private void ShowGameObjects(bool s)
    {
        foreach (GameObject go in FindObjs)
        {
            //Отключаем/Включаем СВЕТА
            if (go.light)
            {
                go.light.enabled = s;
            }

            //Отключаем/Включаем TRAILS
            if (go.GetComponent(typeof (TrailRenderer)))
            {
                TrailRenderer TrailComp = (TrailRenderer) go.GetComponent(typeof (TrailRenderer));
                TrailComp.enabled = s;
            }

            //Выключаем/Включаем meshi из Renderinga
            if (go.GetComponent(typeof (MeshRenderer)))
            {
                go.gameObject.renderer.enabled = s;
            }

            //Выключаем/Включаем TEXTMESH из Renderinga
            if (go.GetComponent(typeof (TextMesh)) && go.GetComponent(typeof(MeshRenderer)))
            {
                go.gameObject.renderer.enabled = s;
            }

            //Выключаем/Включаем GUITEXT из Renderinga
            if (go.GetComponent(typeof (GUIText)))
            {
                GUIText GUITComp = (GUIText) go.GetComponent(typeof (GUIText));
                GUITComp.enabled = s;
            }
            if (go.GetComponent(typeof (GUITexture)))
            {
                GUITexture GUIComp = (GUITexture) go.GetComponent(typeof (GUITexture));
                GUIComp.enabled = s;
            }
            //go.SetActive(s);
        }
    }

    public void CheckEvents()///!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    {
        if (CurEvent == PlayerWinLevelEvent)
        {
            Debug.Log(51);
        }
        if (CurEvent == NewGameEvent)
        {
            
            FirstRun = false;

            PlayerPos = PlayerProt.gameObject.transform;
            p1 = PlayerPos.transform.localPosition;
            p1r = PlayerProt.transform.localRotation;
            EnemyPos = EnemyProt.gameObject.transform;
            e1 = EnemyPos.transform.localPosition;
            e1r = EnemyProt.gameObject.transform.localRotation;

            PlayerProt.gameObject.transform.localPosition = p1;
            PlayerProt.gameObject.transform.localRotation = p1r;
            EnemyProt.gameObject.transform.localPosition = e1;
            EnemyProt.gameObject.transform.localRotation = e1r;

            //ShowGameObjects(true); 
           CurEvent = BackToGameEvent;//PauseGameEvent
            //ButEvent = "MenuEvent";

            GameMode = GameModeRunEvent;

            Enemy.erstep = 0;
            Enemy.EState = Enemy.EStateWait;
            CurTurn = PlayerTurn;
            Player.PState = Player.PStateGo;
            Player.rstep = 0;

        }

        if (CurEvent == PlayerWinLevelEvent)
        {
            
            CurLevel = CurLevel + 1;
            if (CurLevel > FinishLevel)
            {
                
                CurLevel = StartLevel;
                ShowWinGameScreen();
            }
            else
            {
                
                CurEvent = NextLevelEvent;
                GoToNextLevel();
                Debug.Log("Next level");
            }
        }
       

        if (CurEvent == PlayerLoseEvent)
        {
        }

      if (CurEvent == PauseGameEvent)
        {
           ShowGameObjects(false);
        }

        if (CurEvent == BackToGameEvent)
        {
           ShowGameObjects(true); 
        }

    }

    void ShowWinGameScreen()
    {
        Debug.Log("wnin game");
    }

    void GoToNextLevel()
    {
        
    }

    void CheckTurn()
    {

       if (Player.PState == Player.PStateGo)
       {
           //CubCamera.scolor = CubCamera.plrcolor;
           CurTurn = PlayerTurn;
          TText.text = PTurnT;
           MSGN = MSGWait;
       }
       if (Player.PState == Player.PStateWait)
       {
           CurTurn = EnemyTurn;
           TText.text = ETurnT;
           MSGN = MSGGo;
       }
       if (Enemy.EState == Enemy.EStateGo)
       {
          // CubCamera.scolor = CubCamera.encolor;
           MSGN = MSGWait;
           CurTurn = EnemyTurn;
         TText.text = ETurnT;
       }
       if (Enemy.EState == Enemy.EStateWait)
       {
           MSGN = MSGGo;
           CurTurn = PlayerTurn;
          TText.text = PTurnT;
       }  

        if (CurTurn == PlayerTurn)
        {
            CubCamera.scolor = CubCamera.plrcolor;
            if (CurEvent == PlayerWinLevelEvent)
            {
                MSGN = MSGPlayerWin;
            }
        }

        if (CurTurn == EnemyTurn)
        {
            CubCamera.scolor = CubCamera.encolor;
            if (CurEvent == PlayerLoseEvent)
            {
                ButEvent = "MenuEvent";
                Debug.Log(ButEvent);
                MSGN = MSGPlayerLose;
            }
        
        }

    }
}
