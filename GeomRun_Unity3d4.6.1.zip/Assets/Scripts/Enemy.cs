﻿using UnityEngine;
using System.Collections;

public class Enemy : MonoBehaviour
{
    [SerializeField]
    public Light PLight;
    private float ltmr = 0.5f;
    
    public static int EState;
    public static int EStateWait = 0;
    public static int EStateGo = 1;

    public float tmr = 1.0f;
    public static int erstep;
    public float ct=0;
    public float dt = 0.0175f;
    public float EnSpeed = 0.1f;
    public static float es;

    public GameObject Plat1Prot;// ver ||
    public GameObject Plat2Prot;// hor =
    public GameObject Plat3Prot;// |``
    public GameObject Plat4Prot;// ``|
    public GameObject PlatFProt; // Finish

    public TextMesh EKostinum;
    public GameObject IllumPlane;
    public int EndTmr;
    public int g1 = 0;

    public Transform[] lvlse;

    public void GoToStartLevelPos0()
    {
        Debug.Log(33333);
        SetDefVars();
        this.transform.localPosition = lvlse[GameCore.StartLevel].transform.localPosition;
        this.transform.localRotation = lvlse[GameCore.StartLevel].transform.localRotation;
    }

	// Use this for initialization
    void SetDefVars()
    {
        EndTmr = 0;
        erstep = 0;
        EnSpeed = 0.1f;
        tmr = erstep;
        EState = EStateWait;
        UpdateKostinum(erstep);
        StopCoroutine("ETimer1");
    }
	void Start ()
	{
        SetDefVars();
	}

    IEnumerator StartTimerE()
    {
        IllumPlane.SetActive(true);
        StartCoroutine("ETimer1");
        yield return new WaitForSeconds(tmr);
    }

    IEnumerator ETimer1()
    {
        while (true)
        {
            if (GameCore.CurEvent != GameCore.PlayerWinLevelEvent )
            {
                this.transform.Translate(-EnSpeed, 0, 0);
                ct = ct + dt;
                CubCamera.scolor = CubCamera.encolor;
            }
            if (ct >= tmr)
            {
                ct = 0;
                IllumPlane.SetActive(false);
                //StopCoroutine("ETimer1");
                StopAllCoroutines();
                EState = EStateWait;
                Player.PState = Player.PStateGo;
                erstep = 0;
                UpdateKostinum(erstep);
                g1 = 2;
                EndTmr = 1;
            }
            yield return null;
        }
    }
	
	// Update is called once per frame
    private void Update()
    {
        if (GameCore.CurEvent == GameCore.NewGameEvent)
        {
            Debug.Log(44444);
            SetDefVars();
            this.transform.localPosition = lvlse[GameCore.StartLevel].transform.localPosition;
            this.transform.localRotation = lvlse[GameCore.StartLevel].transform.localRotation;
        }

        if (GameCore.CurEvent == GameCore.NextLevelEvent)
        {

            Debug.Log(14141);
            SetDefVars();
        }

        //cur sobitie = vern v igru(v igre)
        if (GameCore.CurEvent == GameCore.BackToGameEvent)
        {
            //proveryam chey hod
            CheckTurn();

            // kostinum illumplane i lblik obnovl
            if (GameCore.CurEvent != GameCore.PlayerWinLevelEvent)
            {

                EKostinum.transform.position = new Vector3(this.transform.position.x - 4, EKostinum.transform.position.y,
                                                           this.transform.position.z - 0.1f);
                IllumPlane.transform.position = new Vector3(this.transform.position.x,
                                                            EKostinum.transform.position.y - 4.9f,
                                                            this.transform.position.z);
                LightBlik();
            }
            // kostinum illumplane i lblik obnovl

        }
    }

    private void LightBlik()
    {
        if (Time.time > ltmr)
        {
            ltmr = ltmr + 0.25f;
            PLight.transform.position = new Vector3(PLight.transform.position.x, Random.Range(0.2f, 1.0f),
                                                         PLight.transform.position.z);

        }
    }
   
    private void CheckTurn()
    {
        if (erstep == 0 && GameCore.CurTurn == GameCore.EnemyTurn && Player.PState == Player.PStateWait && EState ==EStateGo)
        {
            EndTmr = 0;
            CubCamera.scolor = CubCamera.encolor;
            for (int i = 0; i < 11; i++)
            {
                erstep = Random.Range(1, 6 + 1);
            }
            tmr = erstep;
            UpdateKostinum(erstep);
            StartCoroutine(StartTimerE());
        }

    }


    private void UpdateKostinum(int i)
    {
        EKostinum.text = "Kosti = " + i;
    }

    void OnTriggerStay(Collider ColObj)
    {
        if (GameCore.CurEvent != GameCore.PlayerWinLevelEvent)
        {
            if (ColObj.name == PlatFProt.name)
            {
                if (GameCore.CurEvent == GameCore.BackToGameEvent)
                {
                    StopAllCoroutines();
                    SetDefVars();
                    GameCore.CurEvent = GameCore.PlayerLoseEvent;
                    GameCore.MSGN = GameCore.MSGPlayerLose;
                    
                }
                GameCore.MSGN = GameCore.MSGPlayerLose;
            }
        }
    }

    void OnTriggerExit(Collider ColObj)
    {
        if (GameCore.CurEvent != GameCore.PlayerWinLevelEvent)
        {
            if (ColObj.name == PlatFProt.name)
            {
                EnSpeed = 0.1f;
            }
        }
    }
  
    void OnTriggerEnter(Collider ColObj)
    {

        if (GameCore.CurEvent != GameCore.PlayerWinLevelEvent)
        {
            if (ColObj.name == PlatFProt.name)
            {
                GameCore.FirstRun = true;
                GameCore.ButEvent = "MenuEvent";
                GameCore.CurLevel = GameCore.StartLevel;
                GoToStartLevelPos0();
                if (Player.PState == Player.PStateGo)
                {
                    StopAllCoroutines();
                    SetDefVars();
                    GameCore.CurEvent = GameCore.PlayerLoseEvent;
                    GameCore.MSGN = GameCore.MSGPlayerLose;
                }
            }

            if (ColObj.name == Plat1Prot.name)
            {
                EnSpeed = 0.1f*1.3f;
            }

            if (ColObj.name == Plat2Prot.name)
            {
                EnSpeed = 0.1f*1.3f;
            }

            if (ColObj.name == Plat3Prot.name) // |``
            {
                EnSpeed = 0.1f*1.3f;
                this.transform.Rotate(0, -90, 0);
            }

            if (ColObj.name == Plat4Prot.name) // ``|
            {
                EnSpeed = 0.1f*1.3f;
                this.transform.Rotate(0, 90, 0);
            }
        }
    }
}
