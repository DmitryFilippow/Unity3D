﻿using UnityEngine;

public class Cub : MonoBehaviour
{
    public static int State=0;

    private void Start()
    {

    }

    // Update is called once per frame
    private void Update()
    {
    }

    public void OnCollisionEnter(Collision Col)
    {
        if (Col.gameObject.name == "CubePol")
        {
            State = 1;
           
        }
    }
    public void OnCollisionExit(Collision Col)
    {
        if (Col.gameObject.name == "CubePol")
        {
        State = 0;
        }
    }
}