﻿using UnityEngine;
using System.Collections;

public class Level : MonoBehaviour
{
    public Enemy EnemyProt;
    public Enemy WEnemy;
    public Numb NumbProt;
    public Numb WNumb;
    private int LevelStartNum = 0;
    private int LevelEndNum = 10;
	// Use this for initialization
	void Start ()
	{
	   
        //    WEnemy = (Enemy)Instantiate(EnemyProt);
	    
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
