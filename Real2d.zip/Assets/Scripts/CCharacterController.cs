﻿using UnityEngine;
using System.Collections;

public class CCharacterController : MonoBehaviour
{
    //переменная для установки макс. скорости персонажа
    public float maxSpeed = 10f;
    //переменная для определения направления персонажа вправо/влево
    private bool isFacingRight = true;
    //ссылка на компонент анимаций
    private Animator anim;

    private int Ground = 8;

    private GUIText DCText;
    
    //находится ли персонаж на земле или в прыжке?
    private bool isGrounded = false;
    //ссылка на компонент Transform объекта
    //для определения соприкосновения с землей
    public Transform groundCheck;
    //радиус определения соприкосновения с землей
    private float groundRadius = 0.2f;
    //ссылка на слой, представляющий землю
    public LayerMask whatIsGround;
    public float move;

    public static int Damage = 100;

    public Vector3 startPosV;


    // public static int PlayerEvent = 0;
    // public static int PlayerLife = 0;
    // public static int PlayerDie = 1;


    /// <summary>
    /// Начальная инициализация
    /// </summary>

    private void Awake()
    {
        DCText = GameObject.Find("DCText").guiText;
        startPosV = this.gameObject.transform.position;
    }

    void OnGUI()
    {
        
        DCText.text = Damage.ToString() + "%";    
    }

    public void GoToStart()
    {
        this.gameObject.transform.position = startPosV;
        SetDefVars();
    }

    void SetDefVars()
    {
        Damage = 100;
    }
    private void Start()
    {
        anim = GetComponent<Animator>();
    }

    private void RestartGame()
    {
        Application.LoadLevel(Application.loadedLevel);
        GoToStart();
        //CEnemyController.EEvent = CEnemyController.OnLiveEvent;
    
    }

    private void Die()
    {
        RestartGame();
    }

    private void Update()
    {
        if (Input.GetKeyUp(KeyCode.Escape))
        {
            RestartGame();
        }

        if (Damage <= 0)
        {
            Die();
        }

        //если персонаж на земле и нажат пробел...
        if (isGrounded && Input.GetKeyDown(KeyCode.Space))
        {
            //устанавливаем в аниматоре переменную в false
            anim.SetBool("Ground", false);
            //прикладываем силу вверх, чтобы персонаж подпрыгнул
            rigidbody2D.AddForce(new Vector2(0, 600));
        }


    }


    /// <summary>
    /// Выполняем действия в методе FixedUpdate, т. к. в компоненте Animator персонажа
    /// выставлено значение Animate Physics = true и анимация синхронизируется с расчетами физики
    /// </summary>
    private void FixedUpdate()
    {

        //определяем, на земле ли персонаж
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, groundRadius, whatIsGround);
        //устанавливаем соответствующую переменную в аниматоре
        anim.SetBool("Ground", isGrounded);
        //устанавливаем в аниматоре значение скорости взлета/падения
        anim.SetFloat("vSpeed", rigidbody2D.velocity.y);
        //если персонаж в прыжке - выход из метода, чтобы не выполнялись действия, связанные с бегом
        if (!isGrounded)
            return;



        //используем Input.GetAxis для оси Х. метод возвращает значение оси в пределах от -1 до 1.
        //при стандартных настройках проекта 
        //-1 возвращается при нажатии на клавиатуре стрелки влево (или клавиши А),
        //1 возвращается при нажатии на клавиатуре стрелки вправо (или клавиши D)
         move = Input.GetAxis("Horizontal");

        //в компоненте анимаций изменяем значение параметра Speed на значение оси Х.
        //приэтом нам нужен модуль значения
        anim.SetFloat("Speed", Mathf.Abs(move));

        //обращаемся к компоненту персонажа RigidBody2D. задаем ему скорость по оси Х, 
        //равную значению оси Х умноженное на значение макс. скорости
        rigidbody2D.velocity = new Vector2(move * maxSpeed/*+(rigidbody2D.velocity.x/2)*/, rigidbody2D.velocity.y);

        //если нажали клавишу для перемещения вправо, а персонаж направлен влево
        if (move > 0 && !isFacingRight)
            //отражаем персонажа вправо
            Flip();
        //обратная ситуация. отражаем персонажа влево
        else if (move < 0 && isFacingRight)
            Flip();
    }

    /// <summary>
    /// Метод для смены направления движения персонажа и его зеркального отражения
    /// </summary>
    private void Flip()
    {
        //меняем направление движения персонажа
        isFacingRight = !isFacingRight;
        //получаем размеры персонажа
        Vector3 theScale = transform.localScale;
        //зеркально отражаем персонажа по оси Х
        theScale.x *= -1;
        //задаем новый размер персонажа, равный старому, но зеркально отраженный
        transform.localScale = theScale;
    }

    void OnCollisionEnter2D(Collision2D coll)
    {
        if (coll.gameObject.layer == Ground)
            transform.parent = coll.transform;
        if (coll.gameObject.name=="Home") RestartGame();
        if (coll.gameObject.name=="DeathZone") RestartGame();

    }
    void OnCollisionExit2D(Collision2D coll)
    {
        if (coll.gameObject.layer == Ground)
            transform.parent = null;

    }
}
