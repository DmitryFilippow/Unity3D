﻿using UnityEngine;
using System.Collections;

public class CWorld : MonoBehaviour
{
    const int PK = -27;
	
	void Awake ()
	{
	    SetupPhysics();
	}

    void SetupPhysics() { Physics2D.gravity = new Vector2(0, PK); }
	

}
