﻿using UnityEngine;
using System.Collections;

public class CEnemyController : MonoBehaviour
{
    public float maxSpeed = 10f;
    private bool isFacingRight = true;
    private Animator anim;

    private int Ground = 8;
    
    private int Player = 11;
    private bool isGrounded = false;
    public Transform groundCheck;
    private float groundRadius = 0.2f;
    public LayerMask whatIsGround;
    public float move;
    [Range(0.0f,10.0f)]
    public float RadPatrol = 5;

    public float espeed = 1.0f;
    public Vector3 startPosV;
    private float dist;
    public int DK = 10;

    public static int EEvent = 0;
    public static int OnLiveEvent = 1;
    public static int NullEvent = 0;

    private void Awake()
    {
        startPosV = this.gameObject.transform.position;
    }

    public void GoToStart()
    {
        this.gameObject.transform.position = startPosV;
    }

    private void Start()
    {
        anim = GetComponent<Animator>();
    }


    private void Update()
    {
        CheckEvents();
    }

    void CheckEvents()
    {
        if (EEvent == OnLiveEvent)
        {
            OnLive();
            EEvent = NullEvent;
        }
    }

    private void FixedUpdate()
    {
        CheckPos();
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, groundRadius, whatIsGround);
        anim.SetBool("Ground", isGrounded);
        anim.SetFloat("vSpeed", rigidbody2D.velocity.y);
        if (!isGrounded)
            return;

        move =Mathf.Sin(Time.time*RadPatrol);//Input.GetAxis("Horizontal");

        anim.SetFloat("Speed", Mathf.Abs(move));
        rigidbody2D.velocity = new Vector2(move * maxSpeed/*+(rigidbody2D.velocity.x/2)*/, rigidbody2D.velocity.y);
        if (move > 0 && !isFacingRight)
            Flip();
        else if (move < 0 && isFacingRight)
            Flip();
    }

    private void Flip()
    {

        isFacingRight = !isFacingRight;

        Vector3 theScale = transform.localScale;

        theScale.x *= -1;

        transform.localScale = theScale;
    }

    void OnCollisionEnter2D(Collision2D coll)
    {
        if (coll.gameObject.layer == Ground)
            transform.parent = coll.transform;
    
    }
    void OnCollisionExit2D(Collision2D coll)
    {
        if (coll.gameObject.layer == Ground)
            transform.parent = null;

    }

    void CheckPos()
    {
        dist=(Vector2.Distance(transform.position, GameObject.Find("Character").gameObject.transform.position));
        if (dist<=0.95f){OnDie();}
    }
    void OnDie()
    {
        
        GetComponent<SpriteRenderer>().enabled = false;
        GetComponent<BoxCollider2D>().isTrigger = true;
        GetComponent<CEnemyController>().enabled = false;
        CCharacterController.Damage = CCharacterController.Damage - DK;
    }
    void OnLive()
    {
        /*gameObject.transform.position = startPosV;
        GetComponent<BoxCollider2D>().isTrigger = false;
        
        Debug.Log(166);
        GetComponent<SpriteRenderer>().enabled = true;
        */
    }

}
