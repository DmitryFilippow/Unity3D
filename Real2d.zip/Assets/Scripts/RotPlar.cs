﻿using UnityEngine;
using System.Collections;

public class RotPlar : MonoBehaviour
{
    
    private Transform tr;
    public float nr=0,my=0,mx=0;
    public float rot2k=1;
    public float rotspeed = 10f;
    public float speed = 1f;
    public float amp = .1f;

    public enum PlatType
    {
        None=0,
        Rotor=1,
        Rotor2=2,
        VerticalRun=3,
        HorRun=4,
        DiagRun=5
    }

    void Awake()
    {
        tr = gameObject.transform;
    }
    public PlatType SetPlatformType;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    
    void FixedUpdate()
    {
        
        switch (SetPlatformType)
        {
                case PlatType.None:
                nr = 0;
                break;
                case PlatType.Rotor:
                nr = rotspeed*(1.5f * Time.fixedDeltaTime);
                break;
                case PlatType.Rotor2:
                nr = rotspeed*(Mathf.Sin(1.5f * Time.time)*rot2k);
                break;
                case  PlatType.VerticalRun:
                my = amp*(Mathf.Sin(Time.time*speed));
                break;
                case  PlatType.HorRun:
                mx = amp * (Mathf.Sin(Time.time * speed));
                break;
                case PlatType.DiagRun:
                mx = amp * (Mathf.Sin(Time.time * speed));
                my = mx;
                break;
        }
        if (nr > 360)
        {
            nr = 0;
        }

        tr.Rotate(0, 0, nr);
        tr.Translate(new Vector2(mx,my));
    }

}
