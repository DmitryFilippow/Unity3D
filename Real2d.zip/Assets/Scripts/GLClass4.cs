﻿using UnityEngine;
using System.Collections;

public class GLClass4 : MonoBehaviour {
    public Material mat;
	public Color col1=new Color(1f,0f,0f);
	public Color col2=new Color(.8f,0f,0f);
	public Color col3=new Color(.6f,0f,0f);
	public Color col4=new Color(.4f,0f,0f);
	public Color col5=new Color(.3f,0f,0f);
	public Color col6=new Color(.2f,0f,0f);
	public Color col7=new Color(.1f,0f,0f);
	public Color col8=new Color(0f,0f,0f);


	public float nxK=0.02f;
		public float nyK=0.001f;
     private void SetColor(float t)
    {
        if (t<=100 && t>=75)GL.Color(col1);
        if (t <= 75 && t >= 50) GL.Color(col2);
        if (t <= 50 && t >= 25) GL.Color(col3);
        if (t <= 25 && t >= 0) GL.Color(col4);
        if (t <= 0 && t >= -25) GL.Color(col5);
        if (t <=-25 && t >= -50) GL.Color(col6);
        if (t <= -50 && t >= -75) GL.Color(col7);
        if (t <= -75 && t >= -100) GL.Color(col8);
    }

    

    private void threed()
    {
        vx = vx + .005f;
        vy = vy + .005f;
        vz = vz + .005f;
        for (int n = 1; n < numpoints; n++)
        {
            var x3d = points[n, 0];
            var y3d = points[n, 1];
            var z3d = points[n, 2];
            var ty = ((y3d*Mathf.Cos(vx)) - (z3d*Mathf.Sin(vx)));
            var tz = ((y3d * Mathf.Sin(vx)) + (z3d * Mathf.Cos(vx)));
            var tx = ((x3d * Mathf.Cos(vx)) - (tz * Mathf.Sin(vy)));
                tz = ((x3d * Mathf.Sin(vy)) + (tz * Mathf.Cos(vy)));
            var ox = tx;
                tx = ((tx * Mathf.Cos(vz)) - (ty * Mathf.Sin(vz)));
                ty = ((ox * Mathf.Sin(vz)) + (ty * Mathf.Cos(vz)));
            var nx = (AK*(tx))/(distance - (tz))+BK;
            var ny = (CK - (AK*ty)  / (distance - (tz)));
            SetColor(tz);
            GL.Vertex(new Vector3(nx,ny,0));
            GL.Vertex(new Vector3(nx +nxK, ny + nyK, 0));
            
        }
    }

    //public float AK = 512;
    //public float BK = 320;
    //public float CK = 240;
    //640 480
    public float AK = .001f*((Screen.width/100)*80);
    public float BK = .001f*(Screen.width/2);
    public float CK = .001f*(Screen.height/2);
    //  		nx  = Int(512*(tx#) / (distance - (tz#))) + 320
    //		ny  = Int(240 - (512 * ty#) / (distance - (tz#)))
    public int dots_in_ball = 1440;
    private int numpoints = 1440;
    public int distance = 146;
    private float vx, vy, vz;
    public float[,] points=new float[1440,3];

    void Awake()
    {
        setsphere();
    }

    private void setsphere()
    {
        for (int t = 1; t < dots_in_ball; t++)
        {
            var xd = Random.Range(-90, 90);
            var x0 = (Mathf.Cos(xd)*10f)*(Mathf.Cos(t)*10f);
            var y0 = (Mathf.Cos(xd) * 10f) * (Mathf.Sin(t) * 10f);
            var z0 = Mathf.Sin(xd)*100;
            points[t, 0] = x0;
            points[t, 1] = y0;
            points[t, 2] = z0;
        }
    }

    void OnPostRender()
    {
        if (!mat)
        {
            Debug.LogError("Please Assign a material on the inspector");
            return;
        }
        GL.PushMatrix();
        mat.SetPass(0);

        GL.LoadOrtho();
        GL.Begin(GL.LINES);
        
            //GL.Color(new Color(0, 1, 0));

            //GL.Vertex(new Vector3(Random.Range(0,.05f)+0 + Mathf.Sin(Time.time)/2, Mathf.Sin(Time.time)/2, 0));

         //   GL.Color(new Color(1, 0, 0));

           //GL.Vertex(new Vector3(0.1f + Mathf.Sin(Time.time)/2, Mathf.Sin(Time.time)/2, 0));
       threed();
        GL.End();
        GL.PopMatrix();

    }
}