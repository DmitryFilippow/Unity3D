﻿using UnityEngine;
using System.Collections;

public class GLRain : MonoBehaviour
{
    public Material RMat;
    private int dnums=40;
    public float wind = 0f;
    public struct drop
    {
        public float x, y, angle, col;

    }

    public float al,xx,yy;

/*Function placedrops()
 For n=0 To drop_number
  drip.drop = New drop
  al=Rnd(2048)
  drip\x=al-704
  drip\y=Rnd(380)
  drip\angle=0     ;straight down (This is modified by wind)
  drip\col=Rnd(4)
 Next
End Function
    */

    public drop[] Drop=new drop[40];

    void placedrops()
    {
        Debug.Log(Screen.width+"-"+Screen.height);
         al = 0;
        for (int i = 0; i < dnums; i++)
        {
            al = Random.Range(0, 2048);
            Drop[i].x = al - 704;
            Drop[i].y = Random.Range(0, 380);
            Drop[i].angle = 0;
        }
    }

    void Awake()
    {
        placedrops();
    }


    void OnPostRender()
    {
        
        if (RMat)
        {
            GL.PushMatrix();

            RMat.SetPass(0);
            GL.LoadOrtho();
            
          //  GL.Begin(GL.LINES);
           //     GL.Color(new Color(1,1,1));
           //     GL.Vertex(new Vector3(1,1,0));
           //     GL.Color(new Color(0,0,1));
           //     GL.Vertex(new Vector3(0, 0, 0));
            GL.Begin(GL.LINES);
            Color colv=new Color(1,1,1);
            for (int i = 0; i < dnums; i++)
            {
                Drop[i].angle++;
                xx = Mathf.Sin((2*(Drop[i].angle + wind))*3.14f/360);
                
                yy = Mathf.Cos((2 * (Drop[i].angle + wind)) * 3.14f / 360);
                //yy = yy / Screen.height;
                if (Drop[i].col==0){colv=new Color(0.7f,0.7f,0.7f);}//==+
                else
                {
                    if (Drop[i].col == 1)
                    {
                        colv = new Color(0.5f, 0.5f, 0.5f);
                    }
                    else
                    {
                        if (Drop[i].col == 2)
                        {
                            colv = new Color(0.3f, 0.3f, 0.3f);
                        }
                        else
                        {
                            if (Drop[i].col == 3)
                            {
                                colv = new Color(0.2f, 0.2f, 0.2f);
                            }
                        }
                    }

                }//==-
                
//                GL.Vertex(new Vector3(Drop[i].x/640,Drop[i].y/480, 0));
                
  //              GL.Vertex(new Vector3((Drop[i].x + (xx / 2))/640, (Drop[i].y + (yy / 2))/480, 0));
                
                Drop[i].x = (Drop[i].x/Screen.width) + xx;
                Drop[i].y = (Drop[i].y/Screen.height) + yy;
                if (Drop[i].y / Screen.height > 340 / Screen.height)
                {
                    var percent = Random.Range(0, 100);
                    if (percent < 50 || Drop[i].y / Screen.height > 475 / Screen.height) 
                    {
                        al = Random.Range(0, 2048);
                        Drop[i].x = al - 704;
                        Drop[i].y = Random.Range(0, 100);
                        Drop[i].angle = 0;
                    }
                }
                GL.Color(colv);
                GL.Vertex(new Vector3((Drop[i].x  + (xx / 2)), (Drop[i].y / Screen.height + (yy / 2)), 0));
                GL.Color(colv);
                GL.Vertex(new Vector3(Drop[i].x, Drop[i].y / Screen.height, 0));
            }
            
            GL.End();
            GL.PopMatrix();
            
        }
    }
	/*
Function update()
 ;adjust the 12 at the end of the Sin and Cos lines for faster rain
 For drip.drop = Each drop
  xx=Sin((2*(drip\angle+wind))*Pi/360)*12
  yy=Cos((2*(drip\angle+wind))*Pi/360)*12
  If drip\col=0 Then Color 200,200,200 Else
  If drip\col=1 Then Color 150,150,150 Else
  If drip\col=2 Then Color 100,100,100 Else
  If drip\col=3 Then Color 50,50,50
  Line drip\x,drip\y,drip\x+(xx/2),drip\y+(yy/2)
  drip\x=drip\x+xx
  drip\y=drip\y+yy
  If drip\y>430
   percent=Rnd(100)
   If percent<50 Or drip\y>475
    al=Rnd(2048)
    drip\x=al-704
    drip\y=Rnd(100)
    drip\angle=0     ;straight down (This is modified by wind)
   EndIf
  EndIf
 Next
End Function*/
}
