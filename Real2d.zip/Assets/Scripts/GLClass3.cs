﻿using UnityEngine;
using System.Collections;

public class GLClass3 : MonoBehaviour {
    public Material mat;
    void OnPostRender()
    {
        if (!mat)
        {
            Debug.LogError("Please Assign a material on the inspector");
            return;
        }
        GL.PushMatrix();
        mat.SetPass(0);

        GL.LoadOrtho();
        GL.Begin(GL.LINES);
        for (int i = 0; i < 10; i++)
        {
            GL.Color(new Color(0, 1, 0));

            GL.Vertex(new Vector3(Random.Range(0,.05f)+0 + Mathf.Sin(Time.time)/2, Mathf.Sin(Time.time)/2+i/10f, 0));

            GL.Color(new Color(1, 0, 0));

            GL.Vertex(new Vector3(0.1f + Mathf.Sin(Time.time)/2, Mathf.Sin(Time.time)/2+i/10f, 0));
        }
        GL.End();
        GL.PopMatrix();

    }
}