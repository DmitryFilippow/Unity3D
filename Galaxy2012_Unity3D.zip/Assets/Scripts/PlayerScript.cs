using UnityEngine;
using System.Collections;
// сохраняешь, запускаешь - данные предыдущей игры, а не загруженной - ИСПРАВИТЬ!
public class PlayerScript : MonoBehaviour {
	
	public float PlayerSpeed;
	public GameObject PlayerModel;
	public GameObject EnemyPrefab;
	public GameObject EnemyGroup;
	public GameObject EnemyObject;
	public GameObject ShotPrefab;
	public GameObject ShotPrefab1;
	
	public static int pk;
	public static float posX=0;
	
	private float Timer1 = 0.0f;
	private float Timer2 = 0.0f;
	private float EnemyTime = 2.0f;
	private float ShotTime = 0.65f;
	
	private float eosoldx;
	private float eosoldy;
	private float eosoldz;
	private int eos,eosV;
	private ArrayList AEnemyS = new ArrayList();
	
	private int EnemyCount,i1 = 0;
	private int SelEnemy;
	public static int EnemyOnLev;
	private Vector3 EOldPos;
	private Vector3 ENewPos1;
	private Vector3 ENewPos2;
	private Vector3 EDist1, EDist2, EDist3, EDist4, EDist5, Rast,Rast1,Rast2, Rast3;
	private GameObject ELook;
	private GameObject tmpObject;
	public static GameObject tmpObject3;
	private int EnNum;
	private float EnemySpeed = 1.6f;
	private float n21,n22,n23,n24,n25,n26,n27,n28, n31;
	public float n11,n12,n13,n29,n32, n33,n30;
	
	public static int PlayerLives = 3;
	public static int Scores = 0;
	public static int HighScores = 0;
	public static ArrayList LevelRes = new ArrayList(2);
	const int INGAME = 0;
	const int WINLEVEL = 1;
	const int GAMEOVER = 2;
	const int INMENU = 3;
	
	public static int GameState;
	
	private float EoldX, EoldY, EoldZ;
	public static ArrayList AEnemyPosX = new ArrayList(41);
	public static ArrayList AEnemyPosY = new ArrayList(41);
	public static ArrayList AEnemyPosZ = new ArrayList(41);
	public int eu=0;
	public int f1=0;
	private GameObject tmpObject2;
	
	public static float t1=0;
	private float tk = 1f;
	private Vector3 NVector = new Vector3(0,0,0);
	private float EnemyWS=1.0f;
	private float EnemyT = 1000.0f;
	public int NP1,NP2,NP3;
	private int firstpass = 1;
	public static int GameMode = 0;
	const int GS_NEWGAME = 0;
	const int GS_WINLEVEL = 1;
	const int GS_GAMEOVER = 2;
	const int GS_INGAME = 3;
	const int GS_PAUSE = 4;
	const int GS_EXIT = 5;
	const int GS_WINGAME = 6;
	const int GS_LOADGAME = 7;
	const int GS_SAVEGAME = 8;
	
	public static int FIRSTRUN = 1;
	public static int CurrentLevel = 0;
	public static int FinalLevel = 30;
	
	public int Shot = 0;
	public static int f=0;
	public static int GameLayer = 8;
	
	public static int ckx;
	
	public float KSX, KSY;
	public float KBX = 1.43f;
	public static int Platform=0;
	public const int Android = 1;
	public const int Windows = 2;
	public Vector3 Dir = Vector3.zero;
	public static bool Accel=false;

	void MakeLevel(int num)
	{
		foreach(GameObject Enemys in GameObject.FindGameObjectsWithTag("Enemys"))
		{
			Destroy(Enemys);
		}
		
		
		foreach(GameObject Bangs in GameObject.FindGameObjectsWithTag("Bang"))
		{
			Destroy(Bangs);
		}
		
		AEnemyPosX.Clear();
		AEnemyPosY.Clear();
		AEnemyPosZ.Clear();
		
		firstpass = 1;
		EnemyScript.Num = -1;
		NP1 = Random.Range(0,6);
		NP2 = Random.Range(7,13);
		NP3 = Random.Range(2,4);
		ELook = GameObject.Find("EnemyPoint"+NP1);
		
		tmpObject2 = new GameObject();
		tmpObject3 = new GameObject();
		tmpObject2.transform.position = new Vector3(1000,1000,1000);
		tmpObject3.transform.position = new Vector3(1000,1000,1000);
		
		eosV=0;
		eos=0;
		EnemyCount = 0;
		
		eosoldx=EnemyGroup.transform.position.x;
		eosoldy=EnemyGroup.transform.position.y;
		eosoldz=EnemyGroup.transform.position.z;
		
		/*
		 * 0 - enemyspeed = 1 shoot = 1
		 * 2 - 2 ryada
		 * 5 - 3 ryada
		 * 7 - 4 ryada
		 * 9 - 5 ryadov
		 * 
		 * 10 - enemyspeed = 2 shoot = 2*+
		 * * add fly bonus - shield 10sec
		 * 
		 * 20 - enemyspeed = 3 shhot = 3
		 * add fly bonus - shield 10sec
		 * add fly bonus - double shoot 15sec
		 * 
		 * 30 - enemyspped = 3.5 shoot 3.5
		 * all double shoot
		 * flys - tribpe shoot
		 * 
		
		EnemySpeed = 1.6f;//>
		EnemyTime = 2.0f;//<
		ShotTime = 0.65f;//<moy
		
		*/
		if (num >=29) {eos = 10;eosV = 5; EnemySpeed = 3.5f; EnemyTime = 0.25f;}
		if (num >=20) {eos = 10;eosV = 5; EnemySpeed = 4.0f; EnemyTime = 0.35f;}
		if (num >=10) {eos = 10;eosV = 5; EnemySpeed = 3.0f; EnemyTime = 0.75f;}
		if (num ==9){eos = 10;eosV = 5;}
		if (num <=8){eos = 10;eosV = 4;}
		if (num <=6){eos = 10;eosV = 3;}
		if (num <=4){eos = 10;eosV = 2;}
		if (num <=0){eos = 10;eosV = 1; ShotTime = 0.4f;}
		
		for (var EnemyVert = 0; EnemyVert<eosV; EnemyVert++)
		{
		
		for (var EnemyHor = 0; EnemyHor<eos; EnemyHor++)
		{
		EnemyCount = EnemyCount + 1;
		EnemyObject = (GameObject)Instantiate(EnemyPrefab);
		EnemyObject.layer = GameLayer;
		EnemyObject.transform.position= new Vector3 ((eosoldx+(KSX*11)),eosoldy-(EnemyVert*(KSY*10)),eosoldz);
		AEnemyPosX.Add(EnemyObject.transform.position.x);
		AEnemyPosY.Add(EnemyObject.transform.position.y);
		AEnemyPosZ.Add(EnemyObject.transform.position.z);
		eosoldx = EnemyObject.transform.position.x;
		}
		eosoldx = EnemyGroup.transform.position.x;
		}
			
		eosoldx=EnemyGroup.transform.position.x;
		eosoldy=EnemyGroup.transform.position.y;
		eosoldz=EnemyGroup.transform.position.z;
		
		ShotScript.EnemyCount = EnemyCount;
		EnNum = Random.Range(0,EnemyCount);
		EnemyOnLev = EnemyCount;
		ShotScript.EnemyCount = EnemyOnLev;
		i1=EnemyCount;
	}

	
	
//	void StartC()
//	{
//	StartCoroutine("CMoveEnemyNew");
//	}
	
//	void StopC()
//	{
//		StopCoroutine("CMoveEnemyNew");
//	}
	
	void ShowAndroidUI()
	{
		if (Platform == Android){
	foreach(GameObject AUI in GameObject.FindGameObjectsWithTag("AndroidUI"))
		{
			AUI.gameObject.layer = UIController.MenuLayer;
			AUI.gameObject.renderer.enabled = true;
		}
		
		}
	}
	
	void HideAndroidUI()
	{
		if (Platform == Android){
	foreach(GameObject AUI in GameObject.FindGameObjectsWithTag("AndroidUI"))
		{
			AUI.gameObject.layer = UIController.MenuLayerD;
			AUI.gameObject.renderer.enabled = false;
		}
		}
	}
	
	void ShowLI()
	{
		foreach(GameObject LI in GameObject.FindGameObjectsWithTag("LI"))
		{
			LI.transform.localScale = new Vector3(3.5f,3.5f,3.5f);
		}
	}
	
	void HideLI()
	{
		foreach(GameObject LI in GameObject.FindGameObjectsWithTag("LI"))
		{
			LI.transform.localScale = new Vector3(0,0,0);
		}
	}
	
	// Use this for initialization
	void Start () 
	{
	
		KSX = EnemyPrefab.transform.localScale.z;
		KSY = EnemyPrefab.transform.localScale.x;
		LevelRes.Add("In game");
		LevelRes.Add("Level Win");
		LevelRes.Add("Game over");
		
		GameState = GS_PAUSE;
		
		//StartC();
		//gos = Selection.GetFiltered(GameObject,SelectionMode.Editable);
		//foreach(GameObject AUI1 in FindSceneObjectsOfType(GameObject))
		//{
		//		Debug.Log(AUI1.gameObject.name);
		//}	
	}
	
	void SetDefPlayerPosition()
	{
		transform.position = new Vector3(0,transform.position.y,transform.position.z);
	}
	
	// Update is called once per frame
	void Update ()
	{
		
		switch (GameState) 
		{
		case GS_WINLEVEL:

		CurrentLevel = CurrentLevel + 1;
		Destroy(tmpObject3);
		Destroy(tmpObject2);
		HighScores = HighScores + Scores;
		Scores = 0;
		SetDefPlayerPosition();
			
		if (CurrentLevel<=FinalLevel)
		{
		MakeLevel(CurrentLevel);
		ShowLI();
		GameState=GS_INGAME;
		UpdateUI();
		}
		else
		{
		HideLI();
		GameState=GS_WINGAME;
		UpdateUI();
		}
		GameObject.Find("GameOverMsg").renderer.enabled = false;
		GameObject.Find("GameWinMsg").renderer.enabled = false;
		GameObject.Find("Text1").renderer.enabled = false;
		foreach (GameObject Text1 in GameObject.FindGameObjectsWithTag("Text1"))
		{
			Text1.renderer.enabled = false;
		}
		break;
		
		case GS_INGAME:
		if (PlayerLives==0)
		{
			HideLI();
			GameState = GS_GAMEOVER;
		}
		if (PlayerLives>=1)
		{
			posX=0;
				switch (ckx)
				{
				case 1: CheckKeys(ckx);break;
				case -1:CheckKeys(ckx);break;
				case 0:CheckKeys(ckx);break;
				}
			
			UpdatePlayer();
			
			if (EnemyOnLev>0)
			{
				UpdateEnemy();
			}
			if (EnemyOnLev <=0 && CurrentLevel<=FinalLevel)
			{
				GameState = GS_WINLEVEL;
			}
			if (Accel == false){ ShowAndroidUI();}
			ShowLI();
		}
		GameObject.Find("GameOverMsg").renderer.enabled = false;
		GameObject.Find("GameWinMsg").renderer.enabled = false;
		GameObject.Find("Text1").renderer.enabled = false;
		foreach (GameObject Text1 in GameObject.FindGameObjectsWithTag("Text1"))
		{
			Text1.renderer.enabled = false;
		}
		break;
		
		case GS_SAVEGAME:

		SaveGame();

		if (Accel == false){ShowAndroidUI();}
		ShowLI();
		GameObject.Find("GameOverMsg").renderer.enabled = false;
		GameObject.Find("GameWinMsg").renderer.enabled = false;
		GameObject.Find("Text1").renderer.enabled = false;
		foreach (GameObject Text1 in GameObject.FindGameObjectsWithTag("Text1"))
		{
			Text1.renderer.enabled = false;
		}
		break;
			
			
		case GS_LOADGAME:
		SetDefPlayerPosition();
		LoadGame();
		UpdateUI();
		if (Accel == false){ShowAndroidUI();}
		ShowLI();
		GameObject.Find("GameOverMsg").renderer.enabled = false;
		GameObject.Find("GameWinMsg").renderer.enabled = false;
		GameObject.Find("Text1").renderer.enabled = false;
		foreach (GameObject Text1 in GameObject.FindGameObjectsWithTag("Text1"))
		{
			Text1.renderer.enabled = false;
		}
		break;
			
		case GS_NEWGAME:
		SetDefPlayerPosition();
		StartNewGame();
		UpdateUI();
		if (Accel == false){ShowAndroidUI();}
		ShowLI();
		GameObject.Find("GameOverMsg").renderer.enabled = false;
		GameObject.Find("GameWinMsg").renderer.enabled = false;
		GameObject.Find("Text1").renderer.enabled = false;
		foreach (GameObject Text1 in GameObject.FindGameObjectsWithTag("Text1"))
		{
			Text1.renderer.enabled = false;
		}
		break;
	
		case GS_GAMEOVER:
			
		for (var o1=0; o1<=EnemyCount; o1++)
		{
			Destroy(GameObject.Find("Enemy"+o1));
		}
		
		AEnemyPosX.Clear();
		AEnemyPosY.Clear();
		AEnemyPosZ.Clear();
		UIController.Call = "Menu";
		UpdateUI();
		HideAndroidUI();
		GameObject.Find("GameOverMsg").renderer.enabled = true;
		GameObject.Find("GameWinMsg").renderer.enabled = false;
		GameObject.Find("Text1").renderer.enabled = false;
		foreach (GameObject Text1 in GameObject.FindGameObjectsWithTag("Text1"))
		{
			Text1.renderer.enabled = false;
		}
		break;
		
		case GS_PAUSE:
		HideAndroidUI();
		HideLI();
		GameObject.Find("GameOverMsg").renderer.enabled = false;
		GameObject.Find("GameWinMsg").renderer.enabled = false;
		GameObject.Find("Text1").renderer.enabled = true;
			
		foreach (GameObject Text1 in GameObject.FindGameObjectsWithTag("Text1"))
		{
			Text1.renderer.enabled = true;
		}
		
		break;
		
		case GS_EXIT:
		Debug.Log("!!!!!!!!!!!!!!!!! EXIT");
		Application.Quit();
		break;
		
		case GS_WINGAME:
		PlayerModel.renderer.enabled = false;
		UpdateUI();
		HideAndroidUI();
		GameObject.Find("GameOverMsg").renderer.enabled = false;
		GameObject.Find("GameWinMsg").renderer.enabled = true;
		foreach (GameObject Text1 in GameObject.FindGameObjectsWithTag("Text1"))
		{
			Text1.renderer.enabled = false;
		}
		
		break;

		default:
			MusicList.Message = "play";
		break;
		}
		ckx = 0;
	}
	
	void ShowLifeInd()
	{
		for (var p2=0;p2<=2;p2++)
		{
			GameObject.Find("LifeInd"+p2).gameObject.renderer.enabled = true;
		}
	}
	
	void StartNewGame()
	{
		
		EnemySpeed = 1.6f;//>
		EnemyTime = 2.0f;//<
		ShotTime = 0.65f;//<moy
		
		FIRSTRUN = 0;
		if (!PlayerModel.renderer.enabled){PlayerModel.renderer.enabled = true;}
		Destroy(tmpObject3);
		Destroy(tmpObject2);

		for (var o1=0; o1<=EnemyCount; o1++)
		{
			Destroy(GameObject.Find("Enemy"+o1));
		}
				
		AEnemyPosX.Clear();
		AEnemyPosY.Clear();
		AEnemyPosZ.Clear();

		EnNum = 0;
		
		PlayerLives = 3;
		
		Scores = 0;
		HighScores = Scores;
		firstpass = 1;
		CurrentLevel = 0;
		
		GameState = INGAME;
		
		ShowLifeInd();
		
		MakeLevel(CurrentLevel);
		MusicList.Message = "game";
	}
	
	
	void SaveGame()
	{
		GAMEScript.SStateCurLevel = CurrentLevel;
		
		GAMEScript.SStateHScores = HighScores;
		GAMEScript.SStatePLives = PlayerLives;
		
		GAMEScript.Call = "SaveGame";
		GAMEScript.LSCurLev = CurrentLevel;
		GAMEScript.LSLives = PlayerLives;
		GAMEScript.LSScores = HighScores;
		GameState = INGAME;
		
		for (var p2=0;p2<=GAMEScript.LSLives-1;p2++)
		{
			GameObject.Find("LifeInd"+p2).gameObject.renderer.enabled = true;
		}
		
		MusicList.Message = "game";
	}
	
	void LoadGame()
	{
		FIRSTRUN = 0;
		GAMEScript.Call = "LoadGame";

		if (!PlayerModel.renderer.enabled){PlayerModel.renderer.enabled = true;}
		Destroy(tmpObject3);
		Destroy(tmpObject2);

		for (var o1=0; o1<=EnemyCount; o1++)
		{
			Destroy(GameObject.Find("Enemy"+o1));
		}
		
		foreach(GameObject Bangs in GameObject.FindGameObjectsWithTag("Bang"))
		{
			Debug.Log("DEL!");
			Destroy(Bangs);
		}
		
		foreach(GameObject Bangs in GameObject.FindGameObjectsWithTag("Shot"))
		{
			Debug.Log("DEL2");
			Destroy(Bangs);
		}
		
		AEnemyPosX.Clear();
		AEnemyPosY.Clear();
		AEnemyPosZ.Clear();

		PlayerLives = GAMEScript.LSLives;
		
		Scores = 0;
		HighScores = GAMEScript.LSScores;
		
		
//		firstpass = 1;
		CurrentLevel = GAMEScript.LSCurLev;
		
		GameState = INGAME;
		
		
		for (var p2=0;p2<=2;p2++)
		{
			GameObject.Find("LifeInd"+p2).gameObject.renderer.enabled =false;
		}
		
		for (var p2=0;p2<=PlayerLives-1;p2++)
		{
			GameObject.Find("LifeInd"+p2).gameObject.renderer.enabled = true;
		}
		
		MakeLevel(CurrentLevel);
		MusicList.Message = "game";
	}
	
	
	
	void UpdateUI()
	{
		UIController.LevIndLText = "Level: "+PlayerScript.CurrentLevel;
		UIController.ScorIndLText = "Scores: "+PlayerScript.Scores + "/" + PlayerScript.HighScores ;
		UIController.Call = "UpdateUI";
	}
	
	void UpdatePlayer()
	{
		if (PlayerModel == true)
		{
		
		if (transform.position.x>(EnemyGroup.transform.position.x+(EnemyPrefab.transform.localScale.z*10)*11))
		{
		transform.position = new Vector3((EnemyGroup.transform.position.x+(EnemyPrefab.transform.localScale.z*10)*11)-1,transform.position.y,transform.position.z);
		}
		if (transform.position.x<(EnemyGroup.transform.position.x+EnemyPrefab.transform.localScale.z*11))
		{
		transform.position = new Vector3((EnemyGroup.transform.position.x+EnemyPrefab.transform.localScale.z*11)+1,transform.position.y,transform.position.z);
		}
			
		if (Accel)
			{
			Dir.x = -Input.acceleration.x;
			Dir.z = Input.acceleration.y;
			if (Dir.sqrMagnitude>1)	{Dir.Normalize();}
			Dir*=Time.deltaTime;
			posX=(-Dir.x*100);
			}
			
		transform.Translate(posX,0,0);
		PlayerModel.transform.Rotate(new Vector3(0,0,5));
		if (Shot == 1) PlayerShot();
		}
	}
	
	Vector3 GetDistance(GameObject obj1, GameObject obj2)
	{
		Vector3 Dist;
		Vector3 i2 = obj2.transform.position;
		
		Vector3 i1 = obj1.transform.position;

		Dist = i2 - i1;
		if (Dist.x<0){ Dist.x = Dist.x * -1;}
		if (Dist.y<0){ Dist.y = Dist.y * -1;}
		if (Dist.z<0){ Dist.z = Dist.z * -1;}
		return Dist;
	}
	
	//IEnumerator CShotEnemy()
	//{
	//	while(true)
	//	{
	//	Debug.Log(Time.time);        
	//	yield return new WaitForSeconds(1);
	//	Debug.Log(Time.time);
	//	}
	//}
	
	//IEnumerator CMoveEnemyNew()
	//{
	//	while(PlayerModel == true)
	//	{
	//	yield return new WaitForSeconds(EnemyWS);
	//	}
	//}
	
	void DebugTrace()
	{
//		Debug.DrawLine((GameObject.Find("EnemyPoint"+NP3).transform.position),(GameObject.Find("EnemyPoint"+NP2).transform.position));
//		Debug.DrawLine((GameObject.Find("EnemyPoint"+NP2).transform.position),(GameObject.Find("EnemyPoint"+NP1).transform.position));
	}
	
	void UpdateEnemy()
	{
	
		if (f1>=0){
		
		if (t1>=EnemyT/3 || firstpass == 1)
		{
		
		firstpass = 0;
		EnNum = Random.Range(0,EnemyCount);
		NP1 = Random.Range(0,6);//0
		NP2 = Random.Range(7,13);//3
		NP3 = Random.Range(1,5);//Random.Range(0,6);//2
				
		n23 = (GameObject.Find("EnemyPoint"+NP1).transform.position.x+GameObject.Find("EnemyPoint"+NP2).transform.position.x)/2;
		n24 = (GameObject.Find("EnemyPoint"+NP1).transform.position.y+GameObject.Find("EnemyPoint"+NP2).transform.position.y)/2;

		n25 = (GameObject.Find("EnemyPoint"+NP2).transform.position.x+GameObject.Find("EnemyPoint"+NP3).transform.position.x)/2;
		n26 = (GameObject.Find("EnemyPoint"+NP2).transform.position.y+GameObject.Find("EnemyPoint"+NP3).transform.position.y)/2;

		n27 = (n23+n25)/2;//x centr
		n28 = (n24+n26)/2;//y centr

		tmpObject3.transform.position =( new Vector3(n27,n28,0));
	
		tmpObject = GameObject.Find("Enemy"+EnNum);
		if (tmpObject){
		Rast2 = GetDistance(tmpObject,tmpObject3);
		n29 = (Rast2.x+Rast2.y+Rast2.z)/3;
				
		n30=0.60f;
		if (n29<=16){n30=0.3f;}//1.5
		if (n29>=20){n30=0.41f;}//1.2	//1.051f
		if (n29>=26){n30=0.60f;}//0.8
		if (n29<=0){Debug.Log("!@$E$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");}
		tk = (n29*EnemySpeed)/n29*n30;
		t1=0;
		ELook = GameObject.Find("EnemyPoint"+NP1);
		EDist1 = NVector;
		EDist2 = NVector;
		EDist3 = NVector;
		EDist4 = NVector;
		EDist5 = NVector;
		n11 = 0;
		n12 = 0;
		n13 = 0;
		EoldX = (float)AEnemyPosX[EnNum];
		EoldY = (float)AEnemyPosY[EnNum];
		EoldZ = (float)AEnemyPosZ[EnNum];
		tmpObject2.transform.position=(new Vector3(1000,1000,1000));
		f1=0;
		
		Rast = GetDistance(tmpObject,GameObject.Find("EnemyPoint"+NP1));
		n21 = (Rast.x+Rast.y+Rast.z)/3;
			
		Rast1 = GetDistance(tmpObject,GameObject.Find("EnemyPoint"+NP2));
		n22 = (Rast1.x+Rast1.y+Rast1.z)/3;
		
		Rast3 = GetDistance(tmpObject,GameObject.Find("EnemyPoint"+NP3));
		n31 = (Rast3.x+Rast3.y+Rast3.z)/3;
				}		
		}
			
		t1=t1+tk;
		if (tmpObject == true){
		
		tmpObject.transform.LookAt(ELook.transform.position);
		EDist1=GetDistance(tmpObject,GameObject.Find("EnemyPoint"+NP1));
		EDist2=GetDistance(tmpObject,GameObject.Find("EnemyPoint"+NP2));
		EDist3=GetDistance(tmpObject,tmpObject2);
		EDist4=GetDistance(tmpObject,GameObject.Find("EnemyPoint"+NP3));
			
		EDist5=GetDistance(tmpObject,tmpObject2);			
			
	 	n11 = (EDist1.x+EDist1.y+EDist1.z)/3;
		n12 = (EDist2.x+EDist2.y+EDist2.z)/3;
		n13 = (EDist3.x+EDist3.y+EDist3.z)/3;
		n32 = (EDist4.x+EDist4.y+EDist4.z)/3;
		
		n33 = (EDist5.x+EDist5.y+EDist5.z)/3;
				
		if (n11<=EnemySpeed && f1==0)
		{
			ELook = GameObject.Find("EnemyPoint"+NP2);
			f1=1;
		}
		
		if (n12<=EnemySpeed && f1==1)
			
		{
			ELook = GameObject.Find("EnemyPoint"+NP3);
			f1=2;
		}
			
			if (n32<=EnemySpeed && f1 == 2)
			{
				f1 = 3;
			}
		
		if(f1 ==3)
		{
			EoldX = (float)AEnemyPosX[EnNum];
			EoldY = (float)AEnemyPosY[EnNum];
			EoldZ = (float)AEnemyPosZ[EnNum];
//			Debug.DrawLine(tmpObject.transform.position,new Vector3(EoldX,EoldY,EoldZ));
			tmpObject2.transform.position = (new Vector3(EoldX,EoldY,0));
			ELook = tmpObject2;

		}

		if (n13>=EnemySpeed)
		{
			tmpObject.transform.Translate(0.0f, 0.0f, EnemySpeed);
		}
			else if (n13<=EnemySpeed && f1==3)
			{
				f1=0;
				tmpObject.transform.position = new Vector3(EoldX,EoldY,0);
				tmpObject.transform.LookAt( new Vector3(EoldX,EoldY+1000,0));
				
				if (PlayerLives<1 && tmpObject == true){f1 = -1;}
				if (t1<=300){ t1=300;}
			}
		
				
			if (PlayerModel == true && n13>=0.5f){
			
			if (Time.time>Timer2)
			{
				Timer2 = Time.time+EnemyTime;
				GameObject shots1 = (GameObject)Instantiate(ShotPrefab1);
				shots1.transform.Rotate(new Vector3(0,0,180));
				shots1.transform.position = new Vector3(tmpObject.transform.position.x,tmpObject.transform.position.y-15,0);
			}
				
			}			
//		Debug.DrawLine(tmpObject.transform.position,tmpObject3.transform.position);
		DebugTrace();
		}
			if (tmpObject == false){t1 = 400;}
	
		}
	foreach (GameObject Enemys in GameObject.FindGameObjectsWithTag("Enemys"))
	{
		Enemys.transform.Rotate(new Vector3(0,0.7f,0));
	}
	}
	
	void PlayerShot()
	{
		if (Time.time>Timer1)
			{
			Timer1 = Time.time+(ShotTime*1.6f/2);
			GameObject shots= (GameObject)Instantiate(ShotPrefab);
			shots.transform.position = new Vector3(PlayerModel.transform.position.x,PlayerModel.transform.position.y+15,PlayerModel.transform.position.z);
			}
		Shot = 0;
		f = 0;
	}
	
	void CheckKeys(int x)
	{
		
		switch(x)
		{
		case 0:
		if (Input.GetKey(KeyCode.LeftArrow))
		{
		posX=posX-1;
		}
		if (Input.GetKey(KeyCode.RightArrow))
		{
		posX=posX+1;
		}
		if (Input.GetKey(KeyCode.Space) || f == 1){Shot = 1;}
		break;
		
		case 1:
		posX=posX-1;
		if (Input.GetKey(KeyCode.Space) || f == 1){Shot = 1;}
		break;
		case -1:
		posX=posX+1;
		if (Input.GetKey(KeyCode.Space) || f == 1){Shot = 1;}
		break;
		
		}
	}
}
