using UnityEngine;
using System.Collections;

public class EnemyScript : MonoBehaviour {
	public static int Num = -1;
	public static Vector3 Dist1;
	public static Vector3 Dist2;
	public static Vector3 Dist3;
	public ParticleAnimator shotAnim;
	// Use this for initialization
	void Start (){
		Num=Num+1;
		this.name = "Enemy"+Num;
	}
	
	// Update is called once per frame
	void Update () {
	//Debug.Log(Num);
//	transform.Rotate(0,2,0);
	}
}
