using UnityEngine;

using System.Collections;

public class MainCamera : MonoBehaviour {
	public Material mat;
	private bool stretch = false;
	// Use this for initialization
	void Start () {
	
	}
	
	

	void Update() {
    if(Input.GetKeyDown(KeyCode.Space)) {
        if(stretch) {
            stretch = false;
        } else {
            stretch = true;
        }
    }
}

    private void OnPostRender1()
    {
        //if (!mat) {
        //    Debug.LogError("Please Assign a material on the inspector");
        //    return;
        //}
        if (!mat)
        {
            mat = new Material("Shader \"Hidden/SetAlpha\" {" +
                               "SubShader {" +
                               " Pass {" +
                               " ZTest Always Cull Off ZWrite Off" +
                               " ColorMask A" +
                               " Color (1,1,1,1)" +
                               " }" +
                               "}" +
                               "}"
                );
        }



        GL.PushMatrix();
        GL.LoadOrtho();

        for (var i1 = 0; i1 < mat.passCount; ++i1)
        {
            mat.SetPass(i1);
            GL.Begin(GL.QUADS);

            GL.Vertex3(0.1f, 0.1f, 0.1f);
            GL.Color(new Color(1, 1, 1, 1));
            GL.TexCoord3(0, 1, 0);
            GL.Vertex3(0.81f, 0.1f, 0.1f);
            GL.Color(new Color(1, 1, 1, 1));
            GL.TexCoord3(1, 1, 0);
            GL.Vertex3(0.81f, 0.81f, 0.1f);
            GL.TexCoord3(1, 1, 0);
            GL.Color(new Color(0, 0, 0, 1));
            GL.Vertex3(0.1f, 0.81f, 0.1f);
            GL.End();
        }
        GL.PopMatrix();
    }

    void OnPostRender2()
    {
    mat.SetPass(0);
    GL.LoadPixelMatrix();
    if(stretch) {
        GL.Viewport(new Rect(0,0,Screen.width,Screen.height));
    } else {
        GL.Viewport(new Rect(0,0,Screen.width/2,Screen.height));
    }
   
    GL.Color(Color.yellow);
    GL.Begin(GL.TRIANGLES);
    GL.Vertex3(Screen.width/2,Screen.height/4,0);
    GL.Vertex3(Screen.width/4,Screen.height/2,0);	
    GL.Vertex3(Screen.width - Screen.width/4,Screen.height,0);
    GL.End();
}

}