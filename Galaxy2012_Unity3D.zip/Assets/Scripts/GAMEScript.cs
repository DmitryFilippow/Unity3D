using UnityEngine;
using System;
using System.Collections;
using System.IO;
using System.Xml;

// Android res = 438*238
public class GAMEScript : MonoBehaviour {
	
	public GameObject EZGUI;
	public GameObject EZGUIPrefab;
	public FileStream StateFile;
	
	public static int SStateCurLevel=0;
	public static int SStatePLives=3;
	public static int SStateHScores=0;
	public static int Si;
	
	public static int LStateCurLevel;
	public static string LStateCurLevelS;
	public static int LStatePLives;
	public static int LStateHScores;
	public static int Li;
	
	public int saven=0;
	
	
	
	private XmlNodeList xmlNL;
	private Array XmlArray = new Array[2];
	private String DataPath,SData;
	public XmlDocument XmlDoc = new XmlDocument();
	public XmlDocument xml = new XmlDocument();
	public XmlNode rNode = null;
	public float rmvol,rsvol;
	public static string Call = "none";
	public static int SSCurLev = 0;
	public static int SSScores = 0;
	public static int SSLives = 3;

	public static int LSCurLev = 0;
	public static int LSScores = 0;
	public static int LSLives = 0;
	void InitCfg()
	{
		if (!File.Exists(DataPath+"config.xml"))
		{
			UIController.Call = "OutCfg";
		}
		else
		{
			LoadCfg();
		}
		
	}
	
	void LoadCfg()
	{
		XmlReader rdr = XmlReader.Create(DataPath+"config.xml");
		rdr.ReadStartElement("config");
		rmvol = float.Parse(rdr.ReadElementString("mvol").ToString());
	
		rsvol = float.Parse(rdr.ReadElementString("svol").ToString());
	
		UIController.cfgmvol = rmvol;
		UIController.cfgsvol = rsvol;
	
		UIController.Call = "UpdateCFG";
	}
	
	
	void SaveCfg()
	{
		Debug.Log("OK2");
		XmlWriterSettings XmlCfgSet = new XmlWriterSettings();
		XmlCfgSet.NewLineOnAttributes = true;
		XmlCfgSet.Indent = true;

		XmlWriter writer = XmlWriter.Create(DataPath+"config.xml",XmlCfgSet);

		writer.WriteStartDocument();
		writer.WriteStartElement("config");
		writer.WriteStartElement("mvol");
		writer.WriteValue(Math.Round(UIController.mvol,2));
		writer.WriteEndElement();
		writer.WriteStartElement("svol");
		writer.WriteValue(Math.Round(UIController.svol,2));
		writer.WriteEndElement();
		writer.WriteEndElement();
		writer.WriteEndDocument();
		writer.Close();
		Call = "none";
	}
	
	void Awake()
	{
		//DataPath ="jar:file://" + Application.dataPath +"!/StreamingAssets/Data/";
		SData = Application.persistentDataPath + "/"+"Save0.xml";
		//DataPath =Application.dataPath +"!/StreamingAssets/Data/";
		//win
		
		// DataPath =Application.dataPath+"/"+"StreamingAssets/Data/";
		// andr
			DataPath = Application.persistentDataPath + "/";
		//DataPath ="/sdcard/com.Dikoobraz_art.Galaxy_2012/";
		this.xml = new XmlDocument();
		InitCfg();
		
	}
	// Use this for initialization
	void Start () {
		
				
		//UIController.Call = "UpdateCFG";
		
		
		switch (Application.platform)
		{
		case RuntimePlatform.Android:
		foreach(GameObject AUI in GameObject.FindGameObjectsWithTag("AndroidUI"))
		{
			
			AUI.gameObject.layer = UIController.MenuLayer;
			AUI.gameObject.renderer.enabled = true;
			PlayerScript.Platform = PlayerScript.Android;
		}
		
		break;
			
		case RuntimePlatform.WindowsEditor:
		foreach(GameObject AUI in GameObject.FindGameObjectsWithTag("AndroidUI"))
		{
			
			AUI.gameObject.layer = UIController.MenuLayer;
			AUI.gameObject.renderer.enabled = true;
			PlayerScript.Platform = PlayerScript.Android;
		}
		break;
		}
		
		// 
		//Screen.SetResolution(782,300,false);
		CreateMenus();
		GameInitSaveState();
		
// XML START		
/*
		//InitStateFile();
		//SaveState();
		//LoadState();
		//StateFile = new FileStream("state.dat",FileMode.Create,FileAccess.Write);
		
		XmlWriterSettings XmlSet = new XmlWriterSettings();
		XmlSet.NewLineOnAttributes = true;
		XmlSet.Indent = true;
		 
		XmlWriter writer = XmlWriter.Create(DataPath+"Save"+saven+".xml",XmlSet);
	//	XmlWriter writer = XmlWriter.Create("/sdcard/com.Dikoobraz_art.Galaxy_2012/Save0.xml",XmlSet);
		
		writer.WriteStartDocument();
		writer.WriteStartElement("Save"+saven+".xml");
		writer.WriteStartElement("item");
		writer.WriteValue(SStateCurLevel);
		writer.WriteEndElement();
		writer.WriteStartElement("item");
		writer.WriteValue(SStatePLives);
		writer.WriteEndElement();
		writer.WriteStartElement("item");
		writer.WriteValue(SStateHScores);
		writer.WriteEndElement();
		writer.WriteEndElement();
		writer.WriteEndDocument();
		writer.Close();
//		XmlReader reader = XmlReader.Create(Application.dataPath + "/StreamingAssets/Data/Save"+saven+".xml");
		
		//xml.LoadXml(Resources.Load(DataPath+"Save"+saven).ToString());//  
		xml.LoadXml(Resources.Load("/sdcard/com.Dikoobraz_art.Galaxy_2012/Save"+saven).ToString());//  );//  
		xmlNL = xml.SelectNodes("Save0.xml/item");
		
		//Debug.Log(xmlNL.Item(0).InnerText.ToString());
		LStateCurLevel =int.Parse(xmlNL.Item(1).InnerText.ToString());
		Debug.Log(LStateCurLevel);
		
	*/
	// XML END
		
	}
	
	void CreateMenus()
	{		
		EZGUI = (GameObject)Instantiate(EZGUIPrefab);
		EZGUI.name = "EZUserInterface";
		
	}

	void UpdateMenus()
	{
		
	}
	// Update is called once per frame
	void Update () {
		if (Call == "SaveCfg") SaveCfg();
		if (Call == "LoadGame") GameLoadSaveState(1);
		if (Call == "SaveGame") GameSaveState(1);
	UpdateMenus();
	}
	
	void SaveState()
	{
		
		try
		{
			StateFile = new FileStream("state.dat", FileMode.Open,FileAccess.Write);
		}
		catch (IOException exc)
		{Debug.Log(exc.Message+" Error opening save file");return;}
		
		try
		{
			StateFile.WriteByte((byte)SStateCurLevel);
			StateFile.WriteByte((byte)SStatePLives);
			StateFile.WriteByte((byte)SStateHScores);
		} 
		catch(IOException exc)
		{Debug.Log(exc.Message+" Error save to file");}
		
		
		StateFile.Close();
	}
	
	void LoadState()
	{
		
		try
		{
			StateFile = new FileStream("state.dat", FileMode.Open, FileAccess.Read);
		}
		catch (FileNotFoundException exc)
		{Debug.Log(exc.Message);return;}
		catch 
		{Debug.Log("Error opening file!");return;}
		
		try{
			LStateCurLevel = StateFile.ReadByte();
			LStatePLives = StateFile.ReadByte();
			LStateHScores = StateFile.ReadByte();
			Debug.Log("State="+LStateCurLevel+"="+LStateHScores+"="+LStatePLives+"=");
		}
		catch
			{Debug.Log("Error load state");return;}
	
		
		StateFile.Close();
	}
	
	
	void InitStateFile()
	{
		
		try
		{
			StateFile = new FileStream("state.dat", FileMode.OpenOrCreate);
		}
		
		catch (FileNotFoundException exc)
		{Debug.Log(exc.Message);return;}
		catch 
		{Debug.Log("File error!");return;}
		
		
		StateFile.Close();
	}
	
	void GameSaveState(int sn)
	{
		SSCurLev = SStateCurLevel;
		SSLives = SStatePLives;
		SSScores = SStateHScores;
		PlayerPrefs.SetInt("Slot"+sn+"_CurLev",SSCurLev);
		PlayerPrefs.SetInt("Slot"+sn+"_Lives",SSLives);
		PlayerPrefs.SetInt("Slot"+sn+"_Scores",SSScores);
		PlayerPrefs.Save();
	}
	
	void GameInitSaveState()
	{
		
		if (PlayerPrefs.HasKey("Slot1_CurLev") && PlayerPrefs.HasKey("Slot1_Lives") && PlayerPrefs.HasKey("Slot1_Scores"))
		{
		/*	LSCurLev =  PlayerPrefs.GetInt("Slot1_CurLev");
			LSLives  =  PlayerPrefs.GetInt("Slot1_Lives");
			LSScores =  PlayerPrefs.GetInt("Slot1_Scores");*/
			GameLoadSaveState(1);
		}
		else
		{
		PlayerPrefs.DeleteAll();
		GameSaveState(1);
		GameLoadSaveState(1);
		}
		
	}
	
	void GameLoadSaveState(int sn)
	{
		LSCurLev =  PlayerPrefs.GetInt("Slot"+sn+"_CurLev");
		LSLives  =  PlayerPrefs.GetInt("Slot"+sn+"_Lives");
		LSScores =  PlayerPrefs.GetInt("Slot"+sn+"_Scores");
		Call = "none";
	}
	
}
