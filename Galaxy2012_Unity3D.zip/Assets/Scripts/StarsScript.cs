using UnityEngine;
using System.Collections;

public class StarsScript : MonoBehaviour {
	
	public float u1=0;
	public float v1=0;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

	v1 = v1-0.001f;
	//this.transform.Rotate(new Vector3(0,5,0));
	//renderer.material.mainTextureOffset = new Vector2 (renderer.material.mainTextureOffset.x,renderer.material.mainTextureOffset.y-0.001f);
	if ( v1<=-1f)
		{
			v1 = 0f;
		}
	renderer.material.mainTextureOffset = new Vector2 (renderer.material.mainTextureOffset.x,v1);
	}
}
