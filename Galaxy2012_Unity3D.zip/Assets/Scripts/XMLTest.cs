using UnityEngine;
using System;
using System.Collections;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

public class XMLTest : MonoBehaviour {
	
public string FILE_NAME = "xmltest.xml";
public string DataPath = "";
public XmlDocument XmlDoc = new XmlDocument();
public XmlDocument xml = new XmlDocument();
public XmlNode rNode = null;
public XmlNodeList xmlNL;
public int SSCurLev = 33;
public int SSScores = 1234;
public int SSLives = 3;

public int LSCurLev = 0;
public int LSScores = 0;
public int LSLives = 0;
public string t1s;
public int t1i;
public SpriteText TM;
public ArrayList buf = new ArrayList(10);
	public virtual void SaveGame()
	{
		XmlElement elem1 = XmlDoc.CreateElement("vars");
		
		XmlAttribute AttribCurLev = XmlDoc.CreateAttribute("level");
		AttribCurLev.Value = SSCurLev.ToString();
		
		XmlAttribute AttribScores = XmlDoc.CreateAttribute("scores");
		AttribScores.Value = SSScores.ToString();
		
		XmlAttribute AttribLives = XmlDoc.CreateAttribute("lives");
		AttribLives.Value = SSLives.ToString();
		
		elem1.SetAttributeNode(AttribCurLev);
		elem1.SetAttributeNode(AttribScores);
		elem1.SetAttributeNode(AttribLives);
		rNode.AppendChild(elem1);
		
		XmlDoc.Save(DataPath+FILE_NAME);
		
	}
	
	void SaveGame2()
	{
	}
	
	void LoadGame2()
	{

		XmlWriterSettings XmlSet = new XmlWriterSettings();
		XmlSet.NewLineOnAttributes = true;
		XmlSet.Indent = true;
		 
		XmlWriter writer = XmlWriter.Create(DataPath+"Save.xml",XmlSet);
			
		writer.WriteStartDocument();
		writer.WriteStartElement("save");
		writer.WriteStartElement("level");
		writer.WriteValue(SSCurLev);
		writer.WriteEndElement();
		writer.WriteStartElement("lives");
		writer.WriteValue(SSLives);
		writer.WriteEndElement();
		writer.WriteStartElement("scores");
		writer.WriteValue(SSScores);
		writer.WriteEndElement();
		writer.WriteEndElement();
		writer.WriteEndDocument();
		writer.Close();

		XmlReader rdr = XmlReader.Create(DataPath+"Save.xml");
		rdr.ReadStartElement("save");//Value.ToString();
		
		t1s = rdr.ReadElementString("level").ToString();
		t1s = rdr.ReadElementString("lives").ToString();
		t1i = int.Parse(rdr.ReadElementString("scores"));
		
		rdr.Close();
		buf.Add(96);
		buf.Add(97);
		t1i = t1i+(int)buf[0];
		LSCurLev = t1i;
		

		
		if (PlayerPrefs.HasKey("SSCurLev"))
		{		LSCurLev =  PlayerPrefs.GetInt("SSCurLev");
		}
		else
		{
		PlayerPrefs.SetInt("SSCurLev",SSCurLev);
		PlayerPrefs.Save();
			LSCurLev =  PlayerPrefs.GetInt("SSCurLev")+100;
		}
	}
	
	void LoadGame()
	{
		XmlDoc.Load(DataPath+FILE_NAME);
		rNode = XmlDoc.DocumentElement;
		rNode.RemoveAll();
		
		XmlReader reader = XmlReader.Create(DataPath+FILE_NAME);
		XmlDoc.Load(reader);
		rNode=XmlDoc.GetElementById("vars level");
		LSCurLev = int.Parse(rNode.InnerText.ToString());
	}
	
	void InitSave()
	{
		
		if (!File.Exists(DataPath+FILE_NAME))
		{
			rNode =XmlDoc.CreateElement("save0");
			XmlDoc.AppendChild(rNode);
			SaveGame();
		}
		else
		{
			LoadGame();
		}
	}
	
	
	void Start () 
	{
		//win
		//DataPath = Application.dataPath+"/"+"StreamingAssets/Data/";
		//andr
		//DataPath = "/sdcard/com.Dikoobraz_art.Galaxy_2012/";
		DataPath = Application.persistentDataPath + "/";
		
		//InitSave();
		LoadGame2();
				
		//LSCurLev = int.Parse(XmlDoc.GetElementById("save0/vars level").Attributes.ToString());
//		Debug.Log(LSCurLev);
		
		GAMEScript.LStateCurLevel = LSCurLev;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
