using UnityEngine;
using System.Collections;

public class MusicList : MonoBehaviour {
	
	public static string Message = "menu";
	public const string M_DEF = "none";
	public const string M_PLAY = "play";
	public const string M_STOP = "stop";
	public const string M_GAME = "game";
	public const string M_MENU = "menu";
	
	public AudioClip[] Tracks;
	public const int Menu = 0;
	public const int Game = 1;
	public UIStateToggleBtn mtb;
	public static string Call;
	// Use this for initialization
	void Start () {
	

	audio.loop = true;
	
	
	}
	
	void ChangeMusic(int m){audio.clip = Tracks[m]; PlayMusic();}
	
	void StopMusic()
	{
	audio.Stop();
	}
	void PlayMusic()
	{
		audio.Play();
	}
	
	void MusicOnOff()
	{ 
			if (mtb.StateNum == 0)
			{
				audio.mute = true;
			}
			else
			{
				audio.mute = false;
			}
	}
	void VolMusic(){audio.volume = UIController.inmvol;}
	// Update is called once per frame
	void Update () 
	{
		if (Call == "MusicOnOff"){ Call ="none";MusicOnOff();}
	//	Message = M_DEF;
		switch (Message)
		{
		case M_DEF:
		return;
		break;
		
		case M_MENU:
			ChangeMusic(Menu);
			Message = M_DEF;
		break;
			
		case M_GAME:
			ChangeMusic(Game);
			Message = M_DEF;
		break;
		
		case M_STOP:
			StopMusic();
			Message = M_DEF;
		break;
		
		case M_PLAY:
			PlayMusic();
			Message = M_DEF;
		break;
		
		}
		
	}
}
