using UnityEngine;
using System.Collections;

public class GameFiles : MonoBehaviour {
	
/// <summary>
/// Config.
/// </summary>
	public static void InitCfg()
	{
		UIController.inmvol=0.0f;
		UIController.Call = "UpdateUI";
	}
	
	public static void SaveCfg()
	{
	}
	
	public static void LoadCfg()
	{
	}
	
//////////////////////////////////
/// <summary>
/// save game.
/// </summary>
	public static void InitSaveGame()
	{
		
	}
	
	public static void SaveGame()
	{
	}
	
	public static void LoadGame()
	{
	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
