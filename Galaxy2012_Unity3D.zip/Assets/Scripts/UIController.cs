using UnityEngine;
using System.Collections;

public class UIController : MonoBehaviour {
	
	public int State;
	public static int MenuLayer = 9;
	public static int MenuLayerD = 10;
	public static string Call = "none";
	public SpriteText LevIndL;
	public static string LevIndLText = "Level: ";
	public SpriteText ScorIndL;
	public static string ScorIndLText = "Scores: ";
	public static int posX;
	public UISlider mslider,sslider;
	public static float mvol,svol,cfgmvol, cfgsvol;
	public static float inmvol,insvol,outmvol,outsvol;
	public static bool inmb,insb,outsb,sb,mb,outmb;
	
	public static bool sndmute = false;
	public UIStateToggleBtn stb;
	public UIStateToggleBtn stb1;
	public static bool AccB=true;
	// Use this for initialization
	
	void OutCFG()
	{
		mvol = mslider.Value;
		svol = sslider.Value;
		outmvol = mvol;
		outsvol = svol;
		GAMEScript.Call = "SaveCfg";
	}
	
	void Start () 
	{
		mvol = mslider.Value;
		svol = sslider.Value;
		SndVol();
		MusVol();
		Menu();
		
	}
	
	void MoveLeft(){PlayerScript.ckx = 1;}
	void MoveRight(){PlayerScript.ckx = -1;}
	void Fire(){PlayerScript.f = 1;}
	// Update is called once per frame
	void Update ()
	{
		
		if (Call == "UpdateUI") { Call = "none"; UpdateUI();}
		if (Call == "Menu") { Call = "none"; Menu();}
		if (Call == "UpdateCFG") { Call = "none"; UpdateCFG();}
		if (Call == "OutCfg") { Call = "none"; OutCFG();}
		//if (Call == "Test") { mvol = mvol+0.01f; UpdateUI();}
	}
	void ShowMenu()
	{
	GameObject.Find("SGameBut").layer = MenuLayer;
	GameObject.Find("LGameBut").layer = MenuLayer;
		
	GameObject.Find("NGameBut").layer = MenuLayer;
	GameObject.Find("OptionsBut").layer = MenuLayer;
	GameObject.Find("ExitBut").layer = MenuLayer;
	
	GameObject.Find("SGameBut").renderer.enabled=true;
	GameObject.Find("LGameBut").renderer.enabled=true;
		
	GameObject.Find("NGameBut").renderer.enabled=true;
	GameObject.Find("OptionsBut").renderer.enabled = true;
	GameObject.Find("ExitBut").renderer.enabled = true;	
		
		if(PlayerScript.PlayerLives>0 && PlayerScript.FIRSTRUN == 0 && PlayerScript.CurrentLevel<=PlayerScript.FinalLevel )
		{
			GameObject.Find("BTGameBut").layer = MenuLayer;
			GameObject.Find("BTGameBut").renderer.enabled = true;
		}
		else
		{
		
		GameObject.Find("SGameBut").layer = MenuLayerD;
		GameObject.Find("SGameBut").renderer.enabled = false;
		GameObject.Find("BTGameBut").layer = MenuLayerD;
		GameObject.Find("BTGameBut").renderer.enabled = false;
		}
	}
	
	void HideMenu()
	{
		
	GameObject.Find("LGameBut").layer = MenuLayerD;
	GameObject.Find("SGameBut").layer = MenuLayerD;
	
	GameObject.Find("NGameBut").layer = MenuLayerD;
	GameObject.Find("BTGameBut").layer = MenuLayerD;
	GameObject.Find("OptionsBut").layer = MenuLayerD;
	GameObject.Find("ExitBut").layer = MenuLayerD;

	GameObject.Find("LGameBut").renderer.enabled = false;
	GameObject.Find("SGameBut").renderer.enabled = false;		
		
	GameObject.Find("NGameBut").renderer.enabled = false;
	GameObject.Find("BTGameBut").renderer.enabled = false;
	GameObject.Find("OptionsBut").renderer.enabled = false;
	GameObject.Find("ExitBut").renderer.enabled = false;
	}
	
	void LoadGame()
	{
		EZUIScript.MenuMessage = EZUIScript.MENU_LOAD_GAME;
		HideMenu();
		GameObject.Find("MenuBut").layer = MenuLayer;
		GameObject.Find("MenuBut").renderer.enabled = true;
		MusicList.Message = "game";
	}
	
	void SaveGame()
	{
		EZUIScript.MenuMessage = EZUIScript.MENU_SAVE_GAME;
		HideMenu();
		GameObject.Find("MenuBut").layer = MenuLayer;
		GameObject.Find("MenuBut").renderer.enabled = true;
		MusicList.Message = "game";
	}
	
	void NewGame()
	{

		EZUIScript.MenuMessage = EZUIScript.MENU_NEW_GAME;
		HideMenu();
		GameObject.Find("MenuBut").layer = MenuLayer;
		GameObject.Find("MenuBut").renderer.enabled = true;
		MusicList.Message = "game";
		
	}
	void BTGame()
	{ 
		EZUIScript.MenuMessage = EZUIScript.MENU_BACK_TO_GAME;
		HideMenu();
		GameObject.Find("MenuBut").layer = MenuLayer;
		GameObject.Find("MenuBut").renderer.enabled = true;
	}
	void Options()
	{ 
		
		EZUIScript.MenuMessage = EZUIScript.MENU_OPTIONS;
		HideMenu();
		foreach(GameObject OPTIONS in GameObject.FindGameObjectsWithTag("Options"))
		{
			OPTIONS.gameObject.layer = UIController.MenuLayer;
			OPTIONS.gameObject.renderer.enabled = true;
		}
	}
	void Exit()
	{ 
		EZUIScript.MenuMessage = EZUIScript.MENU_EXIT;
		HideMenu();
	}
	
	void BackMenu()
	{
		OutCFG();
		EZUIScript.MenuMessage = EZUIScript.MENU_OPTIONS;
		ShowMenu();
		foreach(GameObject OPTIONS in GameObject.FindGameObjectsWithTag("Options"))
		{
			OPTIONS.gameObject.layer = UIController.MenuLayerD;
			OPTIONS.gameObject.renderer.enabled = false;
		}
	}
	
	void Menu()	
	{
		PlayerScript.GameState = EZUIScript.GS_PAUSE;
		ShowMenu();
		GameObject.Find("MenuBut").layer = MenuLayerD;
		GameObject.Find("MenuBut").renderer.enabled = false;
		MusicList.Message = "menu";
	}
	
	
	
	public void UpdateCFG()
	{
		mvol = cfgmvol;
		svol = cfgsvol;
		mslider.Value = mvol;
		sslider.Value = svol;
		SndVol();
		MusVol();
	}
	
	void UpdateUI()
	{
		LevIndL.Text = LevIndLText;
		ScorIndL.Text = ScorIndLText;
	}
	void MusVol()
	{
		if (Call == "UpdateCFG")
		{
			mslider.Value=inmvol;
		}
		else
		{
			inmvol=mslider.Value;
		};
		mvol =inmvol;
		GameObject.Find("MusicList").audio.volume = mvol;
	}
	void SndVol()
	{
		if (Call == "UpdateCFG")
		{
			sslider.Value=insvol;
		}
		else
		{
			insvol=sslider.Value;
		};
		svol =insvol;


		GameObject.Find("UICamera").audio.volume = svol;
	}
	
	void SoundOnOff()
	{
		if (stb.StateNum==0)
			{
				sndmute = true;
				insb = false;
			}
		if (stb.StateNum==1)
			{
				sndmute = false;
				insb =true;
			}
		
		GameObject.Find("UICamera").audio.mute = sndmute;
	}
	void AccOnOff()
	{
		if (stb1.StateNum==0)
		{
			AccB = true;
			GameObject.Find("LBUT").gameObject.renderer.enabled=false;
			GameObject.Find("RBUT").gameObject.renderer.enabled=false;
			GameObject.Find("FireBut").gameObject.renderer.enabled=true;
		}
		if (stb1.StateNum==1)
		{
			AccB = false;
			GameObject.Find("LBUT").gameObject.renderer.enabled=true;
			GameObject.Find("RBUT").gameObject.renderer.enabled=true;
			GameObject.Find("FireBut").gameObject.renderer.enabled=true;
		}
		PlayerScript.Accel = AccB;			
	}
}
