using UnityEngine;
using System.Collections;
// Shot for enemy
public class ShotScript1 : MonoBehaviour {
	public GameObject shotpart;
	public GameObject BangPrefab;
	const int MENU_SHOW = 6;
	const int GS_INGAME = 3;
	const int GS_NEWGAME = 0;
	const int GS_GAMEOVER = 2;
	const int GS_WINLEVEL = 1;
	// Use this for initialization
	void Start () {
		this.name = "ShotPrefab1";
		this.gameObject.layer = PlayerScript.GameLayer;
		this.audio.volume = UIController.insvol;
		this.audio.mute = UIController.sndmute;
		Instantiate(shotpart,this.transform.position,Quaternion.identity);
		shotpart.particleSystem.gravityModifier=2;
	}
	// Update is called once per frame
	
	void MakeBang()
	{
		GameObject bang = (GameObject)Instantiate(BangPrefab);
		bang.transform.position = new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z);
		
	}
	
	void Update () {
	if (PlayerScript.GameState == GS_NEWGAME ||
		PlayerScript.GameState == GS_GAMEOVER ||
		PlayerScript.GameState == GS_WINLEVEL)
		{
			Destroy(this.gameObject);
		}

		
	if (PlayerScript.GameState == GS_INGAME){
	this.transform.Translate(new Vector3(0,0.5f,0));
	//if (this.transform.position.y>=80 || this.transform.position.y<=-50)
	if (this.transform.position.y<=-50)
		{
			Destroy(this.gameObject);
			foreach(GameObject Bangs in GameObject.FindGameObjectsWithTag("Bang"))
			{
			Destroy(Bangs);
			}
		}
		}
	}
	
	void OnTriggerEnter(Collider obj){

		if (obj.gameObject.name == this.gameObject.name){
			Destroy(this.gameObject);
			Destroy(obj.gameObject);
		}
		
		if (obj.gameObject.name == "PlayerModel")
		{
			Destroy(this.gameObject);
			PlayerScript.PlayerLives=PlayerScript.PlayerLives - 1;
			MakeBang();
			GameObject.Find("Player").transform.position = new Vector3(0,-39,0);
			if (GameObject.Find("LifeInd"+PlayerScript.PlayerLives)) {GameObject.Find("LifeInd"+PlayerScript.PlayerLives).renderer.enabled = false;}
			GameObject.Find("LifeInd"+PlayerScript.PlayerLives).renderer.enabled = false;
			
			if (PlayerScript.PlayerLives<1){
				Destroy(this.gameObject);
				obj.gameObject.renderer.enabled = false;
				EZUIScript.ShowMenu = MENU_SHOW;
				PlayerScript.GameState = GS_GAMEOVER;
			}
		}
		
	}
}
