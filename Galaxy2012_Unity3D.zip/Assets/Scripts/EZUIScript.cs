using UnityEngine;
using System.Collections;

public class EZUIScript : MonoBehaviour {
	
	public static int MenuMessage = 0;
	public static int ShowMenu = 0;
	
	public const int MENU_STAY = 0;
	public const int MENU_NEW_GAME = 1;
	public const int MENU_BACK_TO_GAME = 2;
	public const int MENU_EXIT = 3;
	public const int MENU_OPTIONS = 4;
	public const int MENU_BACK = 5;
	
	public const int MENU_SHOW = 6;
	public const int MENU_HIDE = 7;
	
	public const int MENU_LOAD_GAME = 8;
	public const int MENU_SAVE_GAME = 9;
	
	// Use this for initialization
	
	const int GS_NEWGAME = 0;
	const int GS_WINLEVEL = 1;
	const int GS_GAMEOVER = 2;
	const int GS_INGAME = 3;
	public const int GS_PAUSE = 4;
	const int GS_EXIT = 5;
	const int GS_LOADGAME = 7;
	const int GS_SAVEGAME = 8;
	
	public int pl;
	
	public float ScrW, ScrH;
	
	public const string Caption = "Galaxy 2012";
	
	public int SW,SH,AsW,AsH;
	
	public GameObject LifeIndPrefab, LifeInd;
	public GameObject NGameBut;
	public GameObject BTGameBut;
	public GameObject OptionsBut;
	public GameObject ExitBut;
	public GameObject MenuBut;
	
	public const int MK = 10;
	
	void Start () 
	{
	NGameBut = GameObject.Find("NGameBut");
	BTGameBut = GameObject.Find("BTGameBut");
	OptionsBut = GameObject.Find("OptionsBut");
	ExitBut = GameObject.Find("ExitBut");
	MenuBut = GameObject.Find("MenuBut");
	//100%
	//4:3 = 640:480 800:600 1024:768
	AsW = 4;
	AsH = 3;
	SW = Screen.width;
	SH = Screen.height;
	if ((Screen.width/5)==(Screen.height/4)) { AsW = 5; AsH = 4;}
	if ((Screen.width/16)==(Screen.height/10)) { AsW = 16; AsH = 10;}
	if ((Screen.width/16)==(Screen.height/9)) { AsW = 16; AsH = 9;}
	if ((Screen.width/4)==(Screen.height/3)) { AsW = 4; AsH = 3;}
		// 640 480 640/1000= 0.64 0-40 0-30
	ScrW = Screen.width/1000;
	ScrH = Screen.height/1000;
		
	ShowMenu = MENU_SHOW;
	AddLifeInd();
	}
	
	void AddLifeInd()
	{
		pl = PlayerScript.PlayerLives-1;
		for (var p1=0; p1<=pl;p1++)
		{
		LifeInd = (GameObject)Instantiate(LifeIndPrefab);
		LifeInd.layer = PlayerScript.GameLayer;
		LifeInd.name = "LifeInd"+p1;
		LifeInd.transform.position = new Vector3 (108,45-(p1*LifeInd.transform.localScale.y*MK),-15f);
		}
	}

	
	// Update is called once per frame
	void Update () {
		/*
		switch (ShowMenu)
		{
			
		// отображать глав меню...
		case MENU_SHOW:		
		 
		if (NGameBut)
		{
			MenuMessage = MENU_NEW_GAME;
		}
		
		if(PlayerScript.PlayerLives>0 && PlayerScript.FIRSTRUN == 0 ){
		if(BTGameBut)
		{
			MenuMessage = MENU_BACK_TO_GAME;
		}
			}
			
		if(OptionsBut)
		{
			MenuMessage = MENU_OPTIONS;
		}
		
		if(ExitBut)
		{
			MenuMessage = MENU_EXIT;
		}
		break;
		//...
			
		case MENU_HIDE:// скрыть кнопку меню показать глав меню...
			if (MenuBut)
			{
				ShowMenu = MENU_SHOW;
				PlayerScript.GameState = GS_PAUSE;
			}
		break;
		//...
		}
		*/
		CheckMenuMessages();
	}
	
	public static void ShowMMenu()
	{
		
	}
	
	void CheckMenuMessages()
	{
		
		switch(MenuMessage)
		{
		case MENU_SAVE_GAME:
		Debug.Log("Save game");
		ShowMenu = MENU_HIDE;
		PlayerScript.GameState = GS_SAVEGAME;
		MenuMessage = MENU_BACK_TO_GAME;
		break;			
			
		case MENU_LOAD_GAME:
		Debug.Log("Load game");
		ShowMenu = MENU_HIDE;
		PlayerScript.GameState = GS_LOADGAME;
		MenuMessage = MENU_BACK_TO_GAME;
		break;
		
		case MENU_NEW_GAME:
		ShowMenu = MENU_HIDE;
		PlayerScript.GameState = GS_NEWGAME;
		MenuMessage = MENU_BACK_TO_GAME;
		break;
	
		case MENU_BACK_TO_GAME:
		ShowMenu = MENU_HIDE;
		PlayerScript.GameState = GS_INGAME;
		if (PlayerScript.Accel==true & PlayerScript.Platform == PlayerScript.Android){
				GameObject.Find("FireBut").gameObject.renderer.enabled = true;
				GameObject.Find("FireBut").layer = UIController.MenuLayer;
			}
			else
			{
				GameObject.Find("FireBut").gameObject.renderer.enabled = false;
				GameObject.Find("FireBut").layer = UIController.MenuLayerD;
			}
		MusicList.Message = "game";
		MenuMessage = MENU_STAY;
		break;

		case MENU_OPTIONS:
		Debug.Log("Options");
		ShowMenu = MENU_SHOW;
		PlayerScript.GameState = GS_PAUSE;
		MenuMessage = MENU_STAY;
		break;
		
		case MENU_EXIT:
		Debug.Log("Exit");
		ShowMenu = MENU_HIDE;
		PlayerScript.GameState = GS_EXIT;
		MenuMessage = MENU_STAY;
		break;
			
		default:
		break;
		}
	}
}
