using UnityEngine;
using System.Collections;
//Shot for player
public class ShotScript : MonoBehaviour {

	public static int EnemyCount;
	public GameObject BangPrefab;
	public GameObject shotpart;
	
	const int GS_INGAME = 3;
	const int GS_NEWGAME = 0;
	const int GS_GAMEOVER = 2;
	const int GS_WINLEVEL = 1;
	// Use this for initialization
	
	void MakeBang()
	{
		GameObject bang = (GameObject)Instantiate(BangPrefab);
		bang.transform.position = new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z);
		
	}
	
	void Start () {
		this.name = "ShotPrefab";
		this.gameObject.layer = PlayerScript.GameLayer;
		this.audio.volume = UIController.insvol;
		this.audio.mute = UIController.sndmute;
		Instantiate(shotpart,this.transform.position,Quaternion.identity);
	shotpart.particleSystem.gravityModifier=-2;
	}
	
	void UpdateUI()
	{
		UIController.ScorIndLText = "Scores: "+PlayerScript.Scores + "/" + PlayerScript.HighScores ;
		UIController.Call = "UpdateUI";
	}
	
	// Update is called once per frame
	void Update () {
	if (PlayerScript.GameState == GS_NEWGAME ||
		PlayerScript.GameState == GS_GAMEOVER ||
		PlayerScript.GameState == GS_WINLEVEL)
		{
			Destroy(this.gameObject);
		}

	if (PlayerScript.GameState == GS_INGAME){
	this.transform.Translate(new Vector3(0,0.5f,0));
	//if (this.transform.position.y>=80 || this.transform.position.y<=-50)
	if (this.transform.position.y>=80)
		{
			Destroy(this.gameObject);
			foreach(GameObject Bangs in GameObject.FindGameObjectsWithTag("Bang"))
			{
			Destroy(Bangs);
			}
		}
		}
	}
	
	void OnTriggerEnter(Collider obj){
	
		for (var erange=0;erange<=EnemyCount;erange++)
		{
		
		if (obj.gameObject.name == this.gameObject.name){
			Destroy(this.gameObject);
			Destroy(obj.gameObject);
		}			
			
		if (obj.gameObject.name == "Enemy"+erange){
			PlayerScript.Scores = PlayerScript.Scores +100;
			UpdateUI();
			Destroy(this.gameObject);
			Destroy(obj.gameObject);
			MakeBang();
			if (PlayerScript.EnemyOnLev>=1){	PlayerScript.EnemyOnLev = PlayerScript.EnemyOnLev - 1;}
		}
		}
		
		if (obj.gameObject.name == "ShotPrefab1"){
			PlayerScript.Scores = PlayerScript.Scores +10;
			UpdateUI();
			Destroy(this.gameObject);
			Destroy(obj.gameObject);
		}
		
		/*if (obj.gameObject.name == "PlayerModel")
		{

			PlayerScript.PlayerLives=0;
		
			Destroy(this.gameObject);
			Destroy(obj.gameObject);
		}*/
		
	}
}
