﻿using UnityEngine;
using System.Collections;

public class CPlayer : MonoBehaviour {

	public Camera PCamera;
	public GameObject Model;
	public Transform tModel,tPCamera;
	private float dx,dy,dz,tspeed,tturbok , drx,dry,drz;
	private KeyCode KUP,KDOWN,KFORW,KBACK,KMENU,KFIRE;

	public int GMode = 1;
	private int GMMenu = 1;
	private int GMLevel = 2;

	private string MWait="wait";
	private string MUp="up";
	private string MDwn="down";
	private string MFrw="forward";
	private string MBck="back";

	public float bulldelay = .25f;

	void AssignKeys()
	{
		KUP = KeyCode.UpArrow;
		KDOWN = KeyCode.DownArrow;
		KFORW = KeyCode.RightArrow;
		KBACK = KeyCode.LeftArrow;
		KFIRE = KeyCode.Space;
		KMENU = KeyCode.Escape;

	}

	void Awake()
	{
		AssignKeys ();
	}
	// Use this for initialization
	void Start () {
		tModel = Model.transform;
		tPCamera = PCamera.transform;
		dx = 0; dy = 0; dz = 0; tspeed = 0.1f;tturbok = 1.11f; drx = 0;dry = 0;drz = 0;
		GMode = CWorld.GameMode;
	}
	
	// Update is called once per frame
	void Update () {
		MoveModel (MFrw);
		CheckKeys ();

	}

	void CheckKeys()
	{
		if (Input.GetKey (KUP)) {MoveModel(MUp);}
		if (Input.GetKey (KDOWN)) {MoveModel(MDwn);}
		if (Input.GetKey (KFORW)) {MoveModel(MFrw);}
		if (Input.GetKey (KBACK)) {MoveModel(MBck);}

		if (Input.GetKeyDown (KMENU) && CWorld.GameMode == GMLevel)
			{
			Debug.Log("MENU");
			CWorld.GameMode = GMMenu;
			CWorld.cs = CWorld.statusPauseS;
			return;
			}
		if (Input.GetKeyDown (KMENU) && CWorld.GameMode == GMMenu)
		{
			Debug.Log("MENU 1");
			CWorld.GameMode = GMLevel;
			CWorld.cs = CWorld.statusGameS;
			return;
		}
		if (Input.GetKeyDown (KFIRE) && CWorld.GameMode == GMLevel) {	Fire();	}
	}

	void Fire()
	{
		Invoke ("GetBullFromPool", bulldelay);
	}

	void GetBullFromPool()
	{
		GameObject pobj = CObjectPooler.current.getPoolObject ();
		if (pobj == null)	return;
		pobj.transform.position = new Vector3( 
//		                                      Random.Range(Model.transform.position.x-Mathf.Sin(Time.time)*1.45f,Model.transform.position.x+Mathf.Sin(Time.time)*1.45f), 
		                                      tModel.transform.position.x+2,
		                                      tModel.transform.position.y-.6f, 
		                                      tModel.transform.position.z-3);
		//pobj.transform.rotation = tModel.transform.rotation;
		pobj.SetActive (true);
	}

	void MoveModel(string Dir="wait")
	{
		GMode = CWorld.GameMode;
		if (GMode != GMMenu) {
						switch (Dir) {
				
						case  "wait":
								dx = tspeed;
								break;
						case "down":
								dx = 0;
								dy = -tspeed;
								drz = -5;
								break;
						case "up":
								dx = 0;
								dy = tspeed;
								drz = 5;
								break;
						case "forward":
								dx = tspeed * tturbok;
								break;
						case "back":
								dx = -(tspeed * tturbok) * tturbok;
								break;
						default:
								break;
						}
				
						tModel.Translate (new Vector3 (dx, dy, dz));
						tModel.eulerAngles = (new Vector3 (drx, dry, drz));
						tPCamera.Translate (new Vector3 (dx, 0, 0));
						drx = 0;
						dry = 0;
						drz = 0;
						dy = 0;
				}
	}

}
