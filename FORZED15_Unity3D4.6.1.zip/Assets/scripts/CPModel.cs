﻿using UnityEngine;
using System.Collections;

public class CPModel : MonoBehaviour {
	private float slidelsk = 60f;

	private float edelay=0.25f;
	public Transform tea;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	/*void OnCollisionEnter (Collision co)
	{
		foreach (ContactPoint contact in co.contacts) {
			Debug.DrawRay(contact.point, contact.normal, Color.white);
		}
		if (co.relativeVelocity.magnitude > 2)
						Debug.Log (545);

	}*/
	void OnTriggerEnter(Collider co)
	{
		if (co.gameObject.name == "LevelSlider") {
						co.gameObject.transform.Translate (new Vector3 (slidelsk,0, 0));
			CLevelSlider.LevelSlide();
				}

		if (co.gameObject.name == "EnemyActivator") {
			co.gameObject.transform.Translate (new Vector3 (slidelsk/10,0, 0));
			ShowEnemy();
		}
	}

	void ShowEnemy()
	{

		Invoke ("GetEnemyFromPool", edelay);
	}
	void GetEnemyFromPool()
	{

		GameObject epobj = CEnemyPooler.current.getPoolObject ();
		if (epobj == null)	return;

		epobj.transform.position = new Vector3( 
		                                      //		                                      Random.Range(Model.transform.position.x-Mathf.Sin(Time.time)*1.45f,Model.transform.position.x+Mathf.Sin(Time.time)*1.45f), 
		                                      tea.transform.position.x+2,
		                                      tea.transform.position.y-.6f, 
		                                      tea.transform.position.z-1);
		//pobj.transform.rotation = tModel.transform.rotation;

		epobj.SetActive (true);
	}


}
