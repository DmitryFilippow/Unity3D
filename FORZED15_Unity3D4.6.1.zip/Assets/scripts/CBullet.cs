﻿using UnityEngine;
using System.Collections;

public class CBullet : MonoBehaviour
{

    private float bullspeed = 25f;
	private float bulllife=.9f;
    void OnEnable()
    {
        Invoke("DestroyTimer",bulllife);
    }

    void OnDisable()
    {
        CancelInvoke();
    }
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (CWorld.GameMode != CWorld.GamePause) {
						if (gameObject.active) {
								transform.Translate (0, bullspeed * Time.deltaTime, 0);
						}
				}
	}

    void DestroyTimer()
    {
        gameObject.SetActive(false);
    }

	void OnTriggerEnter(Collider co)
	{
				if (co.gameObject.tag=="enemytag") {
			co.gameObject.SetActive(false);
			this.gameObject.SetActive(false);
				}
		}
}
