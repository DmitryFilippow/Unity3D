﻿using UnityEngine;
using System.Collections;

public class CLevelSlider : MonoBehaviour {

	public GameObject LevelM;
	public static Transform Levelt;
	private static float slidek=60f;
	// Use this for initialization

	void Awake()
	{
		Levelt = LevelM.gameObject.transform;
		}

	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public static void LevelSlide()
	{
		Levelt.transform.Translate (new Vector3 (slidek, 0, 0));
	}
	/*void OnTriggerEnter(Collider co)
	{
		Destroy (co.gameObject);
	}
	*/
}
