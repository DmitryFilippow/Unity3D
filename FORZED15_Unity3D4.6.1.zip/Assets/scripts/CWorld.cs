﻿using UnityEngine;
using System.Collections;

public class CWorld : MonoBehaviour {

    public static int GameMode=1;
	public int GameModeInt;
	private int GMLevel = 2;
	private int GMMenu=1;
	public static int GamePause=1;

	public GUIText status;
	public static int cs = 0;
	public int statusGame=2;
	public int statusPause=1;
	public static int statusGameS=2;
	public static int statusPauseS=1;
	// Use this for initialization
	void Start () {

		OnLevel ();
		//ShowMenu ();
	}

	void OnLevel()
	{
		status.text = "Game";
		GameMode = GMLevel;
	}

	void ShowMenu()
	{
		status.text = "Pause";
		GameMode = GMMenu;
	}

	// Update is called once per frame
	void Update () {
		if (cs != 0) {
			switch(cs)
			{
			case 2:
				OnLevel();

				return;
				//break;
			case 1:
				ShowMenu();

				return;
				//break;
			}

				}
		cs = 0;
		GameModeInt = GameMode;
	}
}
