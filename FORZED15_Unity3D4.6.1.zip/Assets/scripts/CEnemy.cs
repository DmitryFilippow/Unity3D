﻿using UnityEngine;
using System.Collections;

public class CEnemy : MonoBehaviour {

	private float espeed=.06f;
	private float elife=6f;
	// Use this for initialization
	void Start () {
	
	}
	void OnEnable()
	{
		Invoke("DestroyTimer",elife);
	}

	void OnDisable()
	{
		CancelInvoke();
	}

	// Update is called once per frame
	void Update () {

	float ye=			UnityEngine.Random.Range(3f, 8f) * (Mathf.Sin(10 * Mathf.PerlinNoise(Mathf.Sin(1f * 10/2), 10f))/2)+4f;
		if (CWorld.GameMode != CWorld.GamePause) {
			if (gameObject.active) {
				transform.Translate (-espeed*(Time.deltaTime*100),ye*Time.deltaTime, 0);
				transform.Rotate(new Vector3(0,0,Mathf.Sin(ye*50f)/Time.deltaTime));
			}
		}
	}
	void DestroyTimer()
	{
		gameObject.SetActive(false);
	}
	void OnTriggerEnter(Collider co)
	{
		if (co.gameObject.tag=="Player") {
			if (GameObject.Find("PModel").gameObject.activeSelf)
			{
			GameObject.Find("PModel").gameObject.SetActive(false);
			CWorld.GameMode=CWorld.GamePause;
			this.gameObject.SetActive(false);
			}
		}
	}
}
