﻿using System.Collections.Generic;
using UnityEngine;
using System.Collections;

public class CEnemyPooler : MonoBehaviour
{

    public static CEnemyPooler current;
    public GameObject PoolObject;
    public int PoolSize = 20;
    public bool AutoGrow = true;
    public List<GameObject> PoolObjects;
 
    void Awake()
    {
        current = this;
    }

	// Use this for initialization
	void Start () {
	    PoolObjects = new List<GameObject>();
	    for (int i = 0; i <PoolSize; i++)
	    {
	        GameObject pobj = (GameObject) Instantiate(PoolObject);
            pobj.SetActive(false);
            PoolObjects.Add(pobj);
	    }
	}
	
	// Update is called once per frame
	public GameObject getPoolObject () {
	    for (int i = 0; i < PoolObjects.Count; i++)
	    {
	        if (!PoolObjects[i].activeInHierarchy)
	        {
	            return PoolObjects[i];
	        }
	    }
	    if (AutoGrow)
	    {
	        GameObject pobj = (GameObject) Instantiate(PoolObject);
            PoolObjects.Add(pobj);
	        return pobj;
	    }
	    return null;
	}
}
