﻿using UnityEngine;
using System.Collections;
using UnityDll1;
public class UseDll : MonoBehaviour
{
    public Material mat;
    public Class1 gl;
    public Color a, b, c, d,e,f,g,h;
    public float AK=0.3f, BK=0.2f, CK=0.4f;
	// Use this for initialization
	void Start ()
	{
	    a = Color.red;
        b = Color.red;
	    c = Color.red;
	    d = Color.red;
	    e = Color.red;
	    f = Color.red;
	    g = Color.red;
	    h = Color.red;
        gl = new Class1(mat);
	        g2 = new Class1(mat);

	        g2.BK = UnityEngine.Random.Range(0.0f, 0.5f);
            g2.AK = UnityEngine.Random.Range(0.04f, 0.25f);
	        
	    g2.col5 = Color.magenta;
	    //  g2.CK = UnityEngine.Random.Range(0.3f, 0.5f);


	}

    private Class1 g2;
	// Update is called once per frame
	void Update ()
	{
	    gl.AK = AK;
	    gl.BK = BK;
	    gl.CK = CK;
        gl.col1 = a;
        gl.col2 = b;
        gl.col3 = c;
        gl.col4 = d;
        gl.col5 = e;
        gl.col6 = f;
        gl.col7 = g;
        gl.col8 = h;
	    g2.BK = BK;

	}

    void OnPostRender()
    {
        g2.OnPostRender();
        gl.OnPostRender();
        
    }
}
