﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameUIControl : MonoBehaviour
{
    public Image IndDamage, IndFuel, IndTurbo;
    public Text ScoresText, LevelText;
    private float idk,ifk,itk;
	// Use this for initialization
    void Awake()
    {
        idk = IndDamage.transform.localScale.x/100;
        ifk = IndFuel.transform.localScale.x/100;
        itk = IndTurbo.transform.localScale.x/100;
    }
	void Start ()
	{
	    //IndDamage.transform.localScale = new Vector3(idk*100f,IndDamage.transform.localScale.y,0);
	}
	
	// Update is called once per frame
	void Update () {
        
	}
}
