﻿using UnityEngine;
using System.Collections;

public class WheelSkid : MonoBehaviour {

    public GameObject skidCaller;
    public float startSlipValue = 6.5f;
    private Skidmark skidmarks=null;
    private int lastSkidmark =-1;
    private WheelCollider wheel_col;

	// Use this for initialization
	void Start () 
    {
        wheel_col = this.gameObject.GetComponent<WheelCollider>();
        if (FindObjectOfType<Skidmark>())
        {
            
            skidmarks =FindObjectOfType<Skidmark>();
        }
        else
            Debug.Log("No skidmarks object found. Skidmarks will not be drawn");
	}
	
	// Update is called once per frame
	public void FixedUpdate () 
    {
	WheelHit GroundHit;
	wheel_col.GetGroundHit(out GroundHit );
	var wheelSlipAmount = Mathf.Abs( GroundHit.sidewaysSlip );

	if ( wheelSlipAmount > startSlipValue ) //if sideways slip is more than desired value
	{

	Vector3 skidPoint =  GroundHit.point + 2*(skidCaller.rigidbody.velocity) * Time.deltaTime;


	lastSkidmark = skidmarks.AddSkidMark(skidPoint, GroundHit.normal, wheelSlipAmount/25, lastSkidmark);

	}
	else
	{
	lastSkidmark = -1;
	}
	}
}
