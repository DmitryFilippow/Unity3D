﻿using UnityEngine;
using System.Collections;

public class CameraScript : MonoBehaviour
{
    public Transform target;
    private Transform myTransform;
    private float targetHeight = 2.0f;
    private float targetRight = 0.0f;
    private float distance = 6.0f;
    private bool prevButtonRight = false;
    private float maxDistance = 20f;
    private float minDistance = 5f;
    private float xSpeed = 250.0f;
    private float ySpeed = 120.0f;
    private float yMinLimit = -20f;
    private float yMaxLimit = 80f;
    private float zoomRate = 1f;
    private float rotationDampening = 3.0f;
    private float x = 0.0f;
    private float y = 0.0f;
    private float distmod = 0.0f;
    public float targetRotationAngle = 0f, currentRotationAngle = 0f;

    private void Start()
    {
        myTransform = transform;
        Vector3 angles = myTransform.eulerAngles;
        x = angles.y;
        y = angles.x;
        if (rigidbody) rigidbody.freezeRotation = true;
    }


    private void LateUpdate()
    {

        if (Input.GetKeyDown("1"))
        {
            target = GameObject.Find("Center").transform;
            transform.parent = target;   
        }
        if (Input.GetKeyDown("2"))
        {
            target = GameObject.Find("CM").transform;
            transform.parent = target;
        }
        if (Input.GetKeyDown("3"))
        {
            target = GameObject.Find("COM").transform;
            transform.parent = target;
        }

        if (!target) return;

        if (Input.GetMouseButtonUp(0)) prevButtonRight = false;
        if (Input.GetMouseButtonUp(1)) prevButtonRight = true;


        if (Input.GetMouseButton(0) || Input.GetMouseButton(1))
        {
            x += Input.GetAxis("Mouse X")*xSpeed*0.02f;
            y -= Input.GetAxis("Mouse Y")*ySpeed*0.02f;
        }
        else if (prevButtonRight || Input.GetKey(KeyCode.S)|| Input.GetKey(KeyCode.DownArrow))
        {
            if (target == GameObject.Find("CM").transform)
            {
                targetRotationAngle = target.eulerAngles.y;
            }
            else
            {
                targetRotationAngle = target.eulerAngles.y-180;
            }
            currentRotationAngle = myTransform.eulerAngles.y;
                x = Mathf.LerpAngle(currentRotationAngle, targetRotationAngle, rotationDampening*Time.deltaTime);
                //targetRotationAngle = target.eulerAngles.y;
                //currentRotationAngle = myTransform.eulerAngles.y;
                //x = Mathf.LerpAngle(currentRotationAngle, targetRotationAngle, rotationDampening * Time.deltaTime);
            

        }
        else if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))
        {
            //if (target == GameObject.Find("CM").transform)
            if (target == GameObject.Find("CM").transform)
            {
                targetRotationAngle = target.eulerAngles.y+180;
            }
            else
            {targetRotationAngle = target.eulerAngles.y; }
            
            
                
                currentRotationAngle = myTransform.eulerAngles.y;
                x = Mathf.LerpAngle(currentRotationAngle, targetRotationAngle, rotationDampening*Time.deltaTime);
                //targetRotationAngle = target.eulerAngles.y + 180;
                //currentRotationAngle = myTransform.eulerAngles.y;
                //x = Mathf.LerpAngle(currentRotationAngle, targetRotationAngle, rotationDampening*Time.deltaTime);
            }


        
        
        

        distance -= Input.GetAxis("Mouse ScrollWheel")*zoomRate*Mathf.Abs(distance); // * Time.deltaTime
        distance = Mathf.Clamp(distance, minDistance, maxDistance);

        y = ClampAngle(y, yMinLimit, yMaxLimit);

        Quaternion rotation = Quaternion.Euler(y, x, 0);
        Vector3 targetMod = new Vector3(0, -targetHeight, 0) - (rotation*Vector3.right*targetRight);
        int layerMask = 1 << 8;
        layerMask = ~layerMask;
        Vector3 position = target.position - (rotation*Vector3.forward*(distance - distmod) + targetMod);
//        Vector3 position2 = target.position - (rotation*Vector3.forward*(0.1f) + targetMod);

        myTransform.rotation = rotation;
        myTransform.position = position;
        if (targetRotationAngle > 359) targetRotationAngle = 0;

        if (targetRotationAngle < 0) targetRotationAngle = 360;
    }



float  ClampAngle (float angle,float min,float max) {
   if (angle < -360)angle += 360;
   if (angle > 360)angle -= 360;
   return Mathf.Clamp (angle, min, max);
}

}
