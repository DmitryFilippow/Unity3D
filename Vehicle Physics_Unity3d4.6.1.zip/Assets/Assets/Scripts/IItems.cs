﻿using UnityEngine;
using System.Collections;

interface IItems
{
    float value { get; set; }
    void Animate();
}
