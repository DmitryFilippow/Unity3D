﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof (Rigidbody))]
[RequireComponent(typeof (AudioSource))]
public class Car : MonoBehaviour
{
    public WheelCollider WCol_FL;
    public WheelCollider WCol_FR;
    public WheelCollider WCol_BL;
    public WheelCollider WCol_BR;
    public WheelHit WGroundHit;
    private float TLK = 1.0f;
    private float TRK = 1.0f;
    public int FRK = 5000;
    public int BRK = 5000;

    public const float BreakB = 10f;
    //gear box
    public float[] GearR;
    public int CurGear = 0;
    public int CountGears;
    public int SetGear;
    //engine
    public float EngineTor = 600.0f;
    public float MaxEngineRPM = 1500f;//3000.0f;
    public float MinEngineRPM = 800f;//1000.0f;
    public float EngineRPM = 0f;
    public const float EST = 1.0f; //Engine sound temp
    public const float ESTB = 2.0f; //Engine sound temp border set gear or border max rpm
    public float SteerAngle = 15f; //ugol povorota koles
    public Transform COM; //centr massi
    public float CurSpeed; // current speed
    public float maxSpeed = 150f; //max speed
    public AudioSource TormAudio; // sound of break
    public AudioSource CarAudio;
    public float CarAccelerateD; //move Dir val = 1(forward) 0(stop) -1(back)
    public float SpeedDK = 30f;
    public float CarRotD; // Rotate Dir =-1 0 1
    public int DK = 100; // Dir k of speed k=100 - forw 10-back MForw & MBack
    public const int MBack = 10;
    public const int MForw = 100;
    public float AK = 3.6f; //3.6f; 7.2=1.8sec   3.6=3.6sec до 100кмч
    public Rigidbody rb; //rig body car

    public const float Stop = 0f;

    public const float HBreakv = 100f;
    public bool CarHBreak = false;

    public float ox1 = 0;
    public string odostring;
    private int okm = 0;
    private string onulls = "00000";

    public bool SpawnCar = true;

    public struct OdometrStruct
    {
        public int odoint;
        public string odostring;
    }

    public OdometrStruct OdometrData;

    public enum CarControlEnum
    {
        Player = 0,
        Computer = 1
    }

    public CarControlEnum CarController;

    private void CheckGearBox()
    {
        CountGears = GearR.Length;
    }

    public void CarAwake()
    {
        SetupPhysics();
        SetupAudio();
        CheckGearBox();
        //CalcOdometr();
    }


    private void SetupPhysics()
    {
        rb = this.gameObject.GetComponent<Rigidbody>();
        rb.rigidbody.interpolation = RigidbodyInterpolation.Interpolate;
        rb.centerOfMass = Vector3.Scale(COM.localPosition, COM.localScale);
    }

    private void SetupAudio()
    {
        CarAudio = GetComponent<AudioSource>();
        CarAudio.loop = true;

    }

    public void CarUpdate()
    {
        //if (CarController==CarControlEnum.Computer){Debug.Log("Computer!");}
        //if (CarController == CarControlEnum.Player) { Debug.Log("Player!"); }
        UpdateEngine();
        UpdateGears();
        Drive(CarAccelerateD, CarRotD, CarHBreak);
        UpdateSound();

    }

    private void UpdateEngine()
    {
        CurSpeed = rb.velocity.magnitude*AK;

        rb.drag = rb.velocity.magnitude/DK;
        EngineRPM = (WCol_FL.rpm + WCol_FR.rpm)/2*GearR[CurGear];
        //Speed Limiter.
        if (CurSpeed > maxSpeed)
        {
            WCol_FL.motorTorque = 0;
            WCol_FR.motorTorque = 0;
        }
        else
        {
            WCol_FL.motorTorque = EngineTor/GearR[CurGear]*CarAccelerateD;
            WCol_FR.motorTorque = EngineTor/GearR[CurGear]*CarAccelerateD;
        }

    }

    private void UpdateGears()
    {
        if (EngineRPM >= MaxEngineRPM) //up gear
        {
            SetGear = CurGear;
            for (var i = 0; i < CountGears; i++)
            {
                if (WCol_FL.rpm*GearR[i] < MaxEngineRPM)
                {
                    SetGear = i;
                    break;
                }
            }
            CurGear = SetGear;
        }

        if (EngineRPM <= MinEngineRPM) //down gear
        {
            SetGear = CurGear;
            for (var j = CountGears - 1; j >= 0; j--)
            {
                if (WCol_FL.rpm*GearR[j] > MinEngineRPM)
                {
                    SetGear = j;
                    break;
                }
            }
            CurGear = SetGear;
        }
    }

    private void UpdateSound()
    {
        if (CarAudio)
        {
            CarAudio.pitch = Mathf.Abs(EngineRPM/MaxEngineRPM) + EST;
            if (CarAudio.pitch > ESTB)
            {
                CarAudio.pitch = ESTB;
            }
        }

        //SkidAudio.
        WCol_BR.GetGroundHit(out WGroundHit);
        if (TormAudio)
        {
            if (Mathf.Abs(WGroundHit.sidewaysSlip) > BreakB)
            {
                TormAudio.enabled = true;
            }
            else
            {
                TormAudio.enabled = false;
            }
        }

    }

    private void Drive(float mdir = 0f, float rdir = 0f, bool HB = false)
    {
        if (mdir < Stop)
        {
            DK = MBack;
        }
        else
        {
            DK = MForw;
        }
        //Steering
        WCol_FL.steerAngle = SteerAngle*rdir;
        WCol_FR.steerAngle = SteerAngle*rdir;
        //Speed Limiter.
        //if (CurSpeed > maxSpeed)
        //{
        //    WCol_FL.motorTorque = 0;
        //    WCol_FR.motorTorque = 0;
        //}
        //else
        //{
        //    WCol_FL.motorTorque = EngineTor/GearR[CurGear]*CarAccelerateD;
        //    WCol_FR.motorTorque = EngineTor / GearR[CurGear] * CarAccelerateD;
        //}
        //Input.
        if (mdir <= Stop)
        {
            WCol_BL.brakeTorque = SpeedDK;
            WCol_BR.brakeTorque = SpeedDK;
        }
        else if (mdir >= Stop)
        {

            WCol_BL.brakeTorque = 0;
            WCol_BR.brakeTorque = 0;
        }

        //HandBrake
        if (HB)
        {
            WCol_FL.brakeTorque = HBreakv;
            WCol_FR.brakeTorque = HBreakv;
        }
        if (!HB)
        {
            WCol_FL.brakeTorque = 0;
            WCol_FR.brakeTorque = 0;
        }
    }

    public void CalcOdometr()
    {
        if (SpawnCar == true)
        {
            odostring = onulls + okm + " km";
            SpawnCar = false;
        }
        if (okm < 10)
        {
            onulls = "00000";
        }
        if (okm >= 10 && okm < 100)
        {
            onulls = "0000";
        }
        if (okm >= 100 && okm < 1000)
        {
            onulls = "000";
        }
        if (okm >= 1000 && okm < 10000)
        {
            onulls = "00";
        }
        if (okm >= 10000 && okm < 99999)
        {
            onulls = "0";
        }
        if (okm >= 99999 && okm < 999999)
        {
            onulls = "";
        }
        if (okm >= 999999)
        {
            okm = 0;
        }

        if (EngineRPM > 20 || EngineRPM < -20)
        {
            ox1 = ox1 + (((rb.velocity.magnitude/100)/360)/0.4f);
            if (ox1 >= 1f)
            {
                ox1 = 0f;
                okm = okm + 1;
            }
            odostring = onulls + okm + " km";
        }
        OdometrData.odoint = okm;
        OdometrData.odostring = odostring;
    }

    public void WheelAntiRoll(WheelCollider WCL, WheelCollider WCR, int AntiRollK)
    {
        WheelHit whit;
        float travelL = TLK;
        float travelR = TRK;
        bool groundedL = WCL.GetGroundHit(out whit);
        bool groundedR = WCR.GetGroundHit(out whit);
        if (groundedL)
            travelL = (-WCL.transform.InverseTransformPoint(whit.point).y - WCL.radius)/WCL.suspensionDistance;
        if (groundedR)
            travelR = (-WCR.transform.InverseTransformPoint(whit.point).y - WCR.radius)/WCR.suspensionDistance;

        float antiRollForce = (travelL - travelR)*AntiRollK;

        if (groundedL) rb.AddForceAtPosition(WCL.transform.up*-antiRollForce, WCL.transform.position);
        if (groundedR) rb.AddForceAtPosition(WCR.transform.up*antiRollForce, WCR.transform.position);

    }

    
}
