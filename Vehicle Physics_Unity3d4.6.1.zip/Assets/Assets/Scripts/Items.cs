﻿using UnityEngine;
using System.Collections;

public abstract class Items : MonoBehaviour,IItems
{
    protected enum ItemTypes
    {
        Gazoline,
        Turbo,
        Repair,
        Scores,
        BonusScores,
        BonusTime,
        Unknown
    }
//    [SerializeField]
    protected ItemTypes SetType;
    public float value { get; set; }
    public virtual void Animate() { if (!DrawItem()) { Debug.Log(Time.time.ToString()); } }
    public virtual bool DrawItem(){return true;}

    protected virtual bool Test()
    {
        //Debug.Log(11);
        return true;
    }
}
