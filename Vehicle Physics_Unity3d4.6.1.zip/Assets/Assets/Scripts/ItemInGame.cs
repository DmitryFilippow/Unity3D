﻿using UnityEngine;
using System.Collections;

public class ItemInGame : Items
{
    [SerializeField]
    protected float value;
    protected Transform trans;
    protected Material mat;
    private GameObject go;
	void Awake ()
	{
	    go = this.gameObject;
	    mat = this.gameObject.renderer.material; // получаем материал объекта
	    trans = this.gameObject.transform;// получаем transform текущего геом объекта
        InitType();//устанавливаем тип объекта
	    CheckSetUnknown();//проверяем value на -1 и на неизвестный тип объекта, далее ставим рандомно тип и знач
	}
    
    private void InitType()// при добавлении нового типа объекта - добавить проверку сюда и в CheckSetUnknown
    {
        if (this.GetType() == typeof(ItemGazoline)) { SetType = ItemTypes.Gazoline; }
        if (this.GetType() == typeof(ItemTurbo)) { SetType = ItemTypes.Turbo; }
        if (this.GetType() == typeof(ItemRepair)) { SetType = ItemTypes.Repair; }
        if (this.GetType() == typeof(ItemScores)) { SetType = ItemTypes.Scores; }
        if (this.GetType() == typeof(ItemBonusScores)) { SetType = ItemTypes.BonusScores; }
        if (this.GetType() == typeof(ItemBonusTime)) { SetType = ItemTypes.BonusTime; }
        if (this.GetType() == typeof(ItemUnknown)) { SetType = ItemTypes.Unknown; }
    }

    private void CheckSetUnknown()
    {
        if (value == -1 || SetType == ItemTypes.Unknown)
        {
            SetType = (ItemTypes)Random.Range(0, 6);
        rec1:
            switch (SetType)
            {

                case ItemTypes.Gazoline:
                    value = Random.Range(10f, 25f);
                    break;
                case ItemTypes.Turbo:
                    value = Random.Range(10f, 25f);
                    break;
                case ItemTypes.Repair:
                    value = Random.Range(10f, 25f);
                    break;
                case ItemTypes.Scores:
                    value = Random.Range(10f, 100f);
                    break;
                case ItemTypes.BonusScores:
                    value = Random.Range(100f, 250f);
                    break;
                case ItemTypes.BonusTime:
                    value = Random.Range(10f, 25f);
                    break;
                case ItemTypes.Unknown:
                    SetType = (ItemTypes)Random.Range(0, 5);
                    goto rec1;
                    break;
            }
            value = Mathf.RoundToInt(value);
        }
    }

	void Update ()
	{
	    //if (Test()){Debug.Log(Test());}
	}

    public void FixedUpdate()
    {
        Animate();
    }

    private void OnTriggerEnter(Collider co)
    {
        if (DrawItem())
        {
            Debug.Log(co.gameObject.tag);
            go.renderer.enabled = false;
        }
    }

    public override bool DrawItem()
    {
        if (go.renderer.isVisible){return true;}        else{return false;}
    }

}
