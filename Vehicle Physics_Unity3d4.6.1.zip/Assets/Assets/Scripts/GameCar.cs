﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameCar : Car
{
    public Text gt, gt1, gt2;
    public bool Drive;
    // Use this for initialization
    private void Start()
    {
    }

    private void Awake()
    {
        CarAwake();
        Drive = true;
    }

    // Update is called once per frame
    private void Update()
    {
        CheckInput();
        CarUpdate();
        CalcOdometr();
        ShowUI();

    }

    private float t = 0f;

    private void CheckInput()
    {
        if (CarController == CarControlEnum.Player)
        {
            CarAccelerateD = Input.GetAxis("Vertical");
            CarRotD = Input.GetAxis("Horizontal");
            CarHBreak = Input.GetKey(KeyCode.Space);
            if (Input.GetKeyDown(KeyCode.R))
            {
                rb.AddForce(Vector3.up*(Time.timeScale*10000), ForceMode.Impulse);
                rb.AddTorque(Vector3.left*(1000*Time.timeScale), ForceMode.Impulse);
            }
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                Application.Quit();
            }
        }
        //Кусок кода демонстрирующий игру компьютера
        if (CarController == CarControlEnum.Computer)
        {

            //CarAccelerateD = 0.4f;
            if (Time.time > t)
            {
                t = Time.time + Random.Range(1f, 3f);
                //Debug.Log(t);
                CarRotD = Random.Range(Mathf.Sin(Time.deltaTime*1000), Mathf.Sin(Time.deltaTime*1000));
                CarAccelerateD = Random.Range(-0.05f, 0.95f);
                
                Drive = true;

            }
            if (t > 0f && CarAccelerateD > 0 && CurSpeed <= 0.002f && EngineRPM < 60)
            {
                t = t*3;
                CarAccelerateD = -1f;

            }

            if (t > Time.time + 3f && (CarAccelerateD > 0f || CarAccelerateD < 0f) && CurSpeed <= 1f &&
                (EngineRPM < 220 || EngineRPM < 30))
            {
                t = Time.time + 3f;
                CarAccelerateD = Random.Range(-1f,1f);
            }
            if (CarAccelerateD == -.51f && EngineRPM < 50f && CurSpeed < 0.01f)
            {
                CarAccelerateD = 0.51f;
            }

            if (t > t + 1f && (CarAccelerateD > 0f || CarAccelerateD < 0f) && CurSpeed <= 1f &&
                EngineRPM > MaxEngineRPM*3)
            {
                t =0;
                rb.AddForce(Vector3.up*(Time.timeScale*10000), ForceMode.Impulse);
                rb.AddTorque(Vector3.left*(1000*Time.timeScale), ForceMode.Impulse);
           }
            if (EngineRPM > MaxEngineRPM*10)
            {
                t = Time.time + 3f;
                rb.transform.localRotation = Quaternion.identity;
                rb.AddForce(Vector3.up * (Time.timeScale * 10000), ForceMode.Impulse);
                rb.AddTorque(Vector3.left * (1000 * Time.timeScale), ForceMode.Impulse);
                CarAccelerateD = Random.Range(-1f, 1f);
                CarRotD = 0;
                EngineRPM = 0;
            }
            
 CarHBreak = false;
    }

}

private void ShowUI()
    {
        if (gt) gt.text = (Mathf.RoundToInt(CurSpeed)) + " km /h";
        if (gt1)
        {
            if (EngineRPM <= -1)
            {
                EngineRPM *= -1;
            }
            gt1.text = (Mathf.RoundToInt(EngineRPM)) + " RPM";
        } // 150 km/h = 150 000m/3600=

        if (gt2) gt2.text = OdometrData.odostring;
    }

}
