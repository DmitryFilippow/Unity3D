﻿using UnityEngine;
using System.Collections;
//Позиционирование колес относително земли и отрисовка частиц пыли при заносе
public class WheelAlig : MonoBehaviour {

    public WheelCollider SetCollider;
    public GameObject SlipPrefab;
    private float RotVal = 0.0f;
    private Transform tr;
    private WheelHit SetGroundHit;

	// Use this for initialization
	void Start ()
	{
	    tr = gameObject.transform;
	}
	
	// Update is called once per frame
    public void Update()
    {
        RaycastHit hit;
        Vector3 CCP = SetCollider.transform.TransformPoint(SetCollider.center);
        if (Physics.Raycast(CCP, -SetCollider.transform.up,out hit, (SetCollider.suspensionDistance + SetCollider.radius)))
        {
            tr.position = hit.point + (SetCollider.transform.up*SetCollider.radius);
        }
        else
        {
            tr.position = CCP - (SetCollider.transform.up*SetCollider.suspensionDistance);
        }
        tr.rotation = SetCollider.transform.rotation * Quaternion.Euler( RotVal, SetCollider.steerAngle, 0 );
	    RotVal += SetCollider.rpm * ( 360/60 ) * Time.deltaTime;
	    SetCollider.GetGroundHit(out SetGroundHit );
	    if ( Mathf.Abs( SetGroundHit.sidewaysSlip ) > 10 ){DrawDust();}

    }
    private void DrawDust()
    {
        if ( SlipPrefab ) {Instantiate( SlipPrefab, SetGroundHit.point, Quaternion.identity );}
    }
}
