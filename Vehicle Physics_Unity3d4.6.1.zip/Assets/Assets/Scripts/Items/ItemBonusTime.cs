﻿using UnityEngine;
using System.Collections;

public class ItemBonusTime : ItemInGame {

}
