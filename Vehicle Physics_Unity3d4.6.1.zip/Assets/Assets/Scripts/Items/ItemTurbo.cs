﻿using UnityEngine;
using System.Collections;

public class ItemTurbo : ItemInGame {
    public override void Animate()
    {
        mat.color = new Color(1, Mathf.Sin(Time.time) / 20 + Mathf.Cos(Time.time), Mathf.Sin(Time.time));
        trans.eulerAngles = new Vector3(90, Mathf.Sin(Time.time)*1000, 0);
        trans.Translate(Vector3.back*(Mathf.Sin(Time.time)/100));
    }
}
