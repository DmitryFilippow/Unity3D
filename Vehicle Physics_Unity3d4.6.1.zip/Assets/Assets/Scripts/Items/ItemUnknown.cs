﻿using UnityEngine;
using System.Collections;

public class ItemUnknown : ItemInGame
{
    public override void Animate()
    {
//        if(!DrawItem()){Debug.Log(Time.time.ToString());}
        //trans.eulerAngles = new Vector3(90, Mathf.Sin(Time.time) * 1000,0);
        trans.Translate(Vector3.back*(Mathf.Sin(Time.time) / 100));
    }

}
