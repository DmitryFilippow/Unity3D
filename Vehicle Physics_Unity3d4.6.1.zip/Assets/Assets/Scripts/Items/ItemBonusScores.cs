﻿using UnityEngine;
using System.Collections;

public class ItemBonusScores : ItemInGame {

}
