﻿using UnityEngine;
using System.Collections;

public class ItemGazoline : ItemInGame {

    public override void Animate()
    {
        trans.eulerAngles = new Vector3(0f, Mathf.Sin(Time.time) * 100, 0f);
    }
}
