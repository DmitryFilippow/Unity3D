﻿using UnityEngine;
using System.Collections;

public class CompDriver : Driver {

    void Main()
    {
        Debug.Log("Main");
    }
	// Use this for initialization
	void Start () {
        UpdateDatas();
	}
	
	// Update is called once per frame
	void Update () {
	
	}
    public override void UpdateDatas()
    {
        Debug.Log(2);
    }
}
