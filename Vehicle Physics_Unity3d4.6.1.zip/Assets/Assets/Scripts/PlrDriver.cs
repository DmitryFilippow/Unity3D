﻿using UnityEngine;
using System.Collections;

public class PlrDriver : Driver {

	// Use this for initialization
	void Start () {
	UpdateDatas();
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public override void UpdateDatas()
    {
        Debug.Log(3);
        base.UpdateDatas();
    }
}
