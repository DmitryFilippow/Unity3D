﻿using UnityEngine;
using System.Collections;

public class Driver : MonoBehaviour
{
    public string Name = "Driver";
    public DriverRanks SetRank;

    public enum DriverRanks
    {
        Novice,
        Racer,
        Profi
    }
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public virtual void UpdateDatas()
    {
        Debug.Log(1);

    }
}
